library(foreign)

load(paste("/Users/jacobtucker/Google Drive/Master IPE Data (1)/R Conversion Reference/merge_GWNOIFSCOW_RM/","masterGWNOCOWIFS_v2.RDATA",sep=""))
#Rename the dataset
ids = masterGWNOCOWIFS
rm(masterGWNOCOWIFS)

#For some reason country is being read as a factor. We'll change it to a string
ids$country = as.character(ids$country)

#Change the missing value codes to allow for sorting
ids$minyear1[is.na(ids$minyear1)] = -9999
ids$minyear2[is.na(ids$minyear2)] = -9999
ids$maxyear1[is.na(ids$maxyear1)] = 9999
ids$maxyear2[is.na(ids$maxyear2)] = 9999

#Change the name of the COW code to "ccode"
names(ids)[names(ids)=="cow"] = "ccode"

#Merge in the gwno abbreviations
gwnoabbrev.dat = read.dta(paste("/Users/jacobtucker/Google Drive/Master IPE Data (1)/prepped data/","gwnocow_stata12.dta",sep=""))
gwnoabbrev.dat = gwnoabbrev.dat[,c("gwno","gwabbrev","gwname")]
ids = merge(ids,gwnoabbrev.dat,by="gwno",all.x=T,all.y=F)

#Sort the dataframe
ids = ids[order(ids$country,ids$minyear1,ids$minyear2,ids$maxyear1,ids$maxyear2),]

#Add in the country names for Hong Kong and Macao
ids$gwname[ids$gwno==708] = "Hong Kong"
ids$gwname[ids$gwno==709] = "Macao"

#Save the data
save(ids,file=paste(rawdata,"CountryIDsMaster.RDATA",sep=""))
