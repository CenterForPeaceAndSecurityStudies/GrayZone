
#install.packages("xlsx")

library(xlsx)

masterGWNOCOWIFS <- read.xlsx("/Users/Apple/Google Drive/Master IPE Data/R Conversion Reference/merge_GWNOIFSCOW_RM/country_to_gwno_JR.xlsx", sheetIndex = 1, colIndex = c(1, 2, 3, 4, 5, 6))

library(foreign)

#install.packages("readstata13")

library(readstata13)

gwnoCow <- read.dta13("/Users/Apple/Google Drive/Master IPE Data/merge_GWNOIFSCOW_RM/gwnocow.dta")
gwnoIFSNum <- read.dta13("/Users/Apple/Google Drive/Master IPE Data/merge_GWNOIFSCOW_RM/ifsnum_gwno_p.dta")
gwnoIFSabb <- read.dta13("/Users/Apple/Google Drive/Master IPE Data/merge_GWNOIFSCOW_RM/ifs_gwno.dta")

#install.packages("dplyr")

library(dplyr)

#convert from factor to int to have matching types
masterGWNOCOWIFS$gwno <- as.integer(as.character(masterGWNOCOWIFS$gwno))
#force minyear etc. to numeric
masterGWNOCOWIFS$minyear1 <- as.integer(as.character(masterGWNOCOWIFS$minyear1))
masterGWNOCOWIFS$maxyear1 <- as.integer(as.character(masterGWNOCOWIFS$maxyear1))
masterGWNOCOWIFS$minyear2 <- as.integer(as.character(masterGWNOCOWIFS$minyear2))
masterGWNOCOWIFS$maxyear2 <- as.integer(as.character(masterGWNOCOWIFS$maxyear2))

#GWNO year ranges decided by Professor Graham
#We have to think about whether the territories under allied occupation 1945-1949 are more like Prussia or more like East and West Germany.  
#Because the occupied territories were already divided and the new governments were already taking shape during that time, I would say they are more like East and West Germany.
masterGWNOCOWIFS$minyear1[masterGWNOCOWIFS$gwno == 260] <- 1946
masterGWNOCOWIFS$minyear1[masterGWNOCOWIFS$gwno == 265] <- 1946
masterGWNOCOWIFS$maxyear1[masterGWNOCOWIFS$gwno == 265] <- 1990
masterGWNOCOWIFS$minyear1[masterGWNOCOWIFS$gwno == 255] <- 1816
masterGWNOCOWIFS$maxyear1[masterGWNOCOWIFS$gwno == 255] <- 1945

#From 1830-1917 there existed the “Principality of Serbia” (GWNO = 340).
#If a country is named Serbia, it should be assigned GWNO 345 from 1918-2006 and GWNO 340 from 2007 forward. 
#This is one of the only country names that will show up in raw datasets that is associated with two different GWNO codes, depending on the year.
#“Yugoslavia” or “Serbia and Montenegro” are treated the same way. GWNO 345 from 1918-2006, GWNO 340 from 2007 forward.
#GWNO 340 should be called “Principality of Serbia” from 1830-1917. Then it ceases to exist from 1918-2006. From 2007-present it should be called “Serbia”
masterGWNOCOWIFS$minyear1[masterGWNOCOWIFS$gwno == 345] <- 1918
masterGWNOCOWIFS$maxyear1[masterGWNOCOWIFS$gwno == 345] <- 2006

masterGWNOCOWIFS$minyear1[masterGWNOCOWIFS$gwno == 340] <- 1830
masterGWNOCOWIFS$maxyear1[masterGWNOCOWIFS$gwno == 340] <- 1917
masterGWNOCOWIFS$minyear2[masterGWNOCOWIFS$gwno == 340] <- 2007

#South Sudan gained independence in 2011
masterGWNOCOWIFS$minyear1[masterGWNOCOWIFS$gwno == 626] <- 2011


#Korea 
masterGWNOCOWIFS$maxyear1[masterGWNOCOWIFS$gwno == 730] <- 1947
masterGWNOCOWIFS$minyear1[masterGWNOCOWIFS$gwno == 731] <- 1948
masterGWNOCOWIFS$minyear1[masterGWNOCOWIFS$gwno == 732] <- 1948

#Czech Republic founded in 1993 
#We decided to have countries called "Czech Republic" or "Czechoslavakia" given gwno 315 before 1993 and gwno 316 after
czech315_replicate <- subset(masterGWNOCOWIFS, masterGWNOCOWIFS$gwno == 315)
czech316_replicate <- subset(masterGWNOCOWIFS, masterGWNOCOWIFS$gwno == 316)
czech315_replicate$gwno <- 316
czech316_replicate$gwno <- 315
masterGWNOCOWIFS <- rbind(masterGWNOCOWIFS, czech316_replicate)
masterGWNOCOWIFS <- rbind(masterGWNOCOWIFS, czech315_replicate)

masterGWNOCOWIFS$maxyear1[masterGWNOCOWIFS$gwno == 315] <- 1992
masterGWNOCOWIFS$minyear1[masterGWNOCOWIFS$gwno == 316] <- 1993


#From an email: Let’s treat Dyanstic Vietnam and Indochina Vietnam as the same unit. This means:
#“Vietnam”  should take a GWNO of 815 up through 1953.  This code also applies to entries called “North Vietnam” up through 1953. 
#Starting in 1954 “North Vietnam” should get a GWNO of 816 (up through the present). This also applies to entries titled “Vietnam” starting in 1954.
#“South Vietnam” (aka “Republic of Vietnam”) should get a GWNO of 817 starting in 1954 and ending in 1975.  Any entries for South Vietnam before 1954 or after 1975 should be dropped.
masterGWNOCOWIFS$maxyear1[masterGWNOCOWIFS$gwno == 817] <- 1975
masterGWNOCOWIFS$minyear1[masterGWNOCOWIFS$gwno == 817] <- 1954

vietnam816_replicate <- subset(masterGWNOCOWIFS, masterGWNOCOWIFS$gwno == 816)
masterGWNOCOWIFS$minyear1[masterGWNOCOWIFS$gwno == 816] <- 1954
vietnam816_replicate$gwno <- 815
vietnam816_replicate$maxyear1 <- 1953

vietnam815_replicate <- subset(masterGWNOCOWIFS, masterGWNOCOWIFS$gwno == 815)
masterGWNOCOWIFS$maxyear1[masterGWNOCOWIFS$gwno == 815] <- 1953
vietnam815_replicate$gwno <- 816
vietnam815_replicate$minyear1 <- 1954
vietnam815_replicate$maxyear1 <- NA
masterGWNOCOWIFS <- rbind(masterGWNOCOWIFS, vietnam815_replicate)
masterGWNOCOWIFS <- rbind(masterGWNOCOWIFS, vietnam816_replicate)


#left join note the line: drop if _merge==2
masterGWNOCOWIFS <- left_join(masterGWNOCOWIFS, gwnoCow, by = "gwno")

#Jacob adds these in later
masterGWNOCOWIFS$gwabbrev <- NULL
masterGWNOCOWIFS$gwname <- NULL

#unlike GW, COW uses only one number for both Serbia and Yugoslavia
masterGWNOCOWIFS$cow[masterGWNOCOWIFS$gwno == 340] <- 345


#COW treats unified Yemen as a new country
masterGWNOCOWIFS$maxyear1[masterGWNOCOWIFS$gwno == 678] <- 1990
yemenPost1990 <- subset(masterGWNOCOWIFS, masterGWNOCOWIFS$gwno == 678)
yemenPost1990$cow <- 679
yemenPost1990$minyear1 <- 1991
yemenPost1990$maxyear1 <- NA

masterGWNOCOWIFS <- rbind(masterGWNOCOWIFS, yemenPost1990)

#COW treats unified Germany as a successor to Prussia
#We again use the same year conventions as the GWNO codes
#Deal with GWNO260
germanyCOW_Issue <- subset(masterGWNOCOWIFS, masterGWNOCOWIFS$gwno == 260)
masterGWNOCOWIFS$maxyear1[masterGWNOCOWIFS$gwno == 260] <- 1990
germanyCOW_Issue$minyear1 <- 1991
germanyCOW_Issue$cow <- 255
masterGWNOCOWIFS <- rbind(masterGWNOCOWIFS, germanyCOW_Issue)



#IFS merge - left join, drop if _merge==2

masterGWNOCOWIFS <- left_join(masterGWNOCOWIFS, gwnoIFSNum, by = "gwno")
colnames(masterGWNOCOWIFS)[1] <- "country"
masterGWNOCOWIFS$country.y <- NULL
masterGWNOCOWIFS$countryname_raw <- NULL

#IFS abbreviations
masterGWNOCOWIFS <- left_join(masterGWNOCOWIFS, gwnoIFSabb, by = "gwno")


#Handle Yemen  and Russia
#USSR is separate from Russia in IFS

#Note: We are not handling Serbia IFS codes like the old append_ids.do did becuase technically 
#The entries with gwno340 and within that year range shouldn't change ifs codes


masterGWNOCOWIFS$ifscode[masterGWNOCOWIFS$gwno == 678 & masterGWNOCOWIFS$maxyear1 == 1990] <- 459

russiaIFS <- subset(masterGWNOCOWIFS, (masterGWNOCOWIFS$gwno == 365))
russiaIFS$maxyear1 <- 1989
russiaIFS$ifscode <- 974
masterGWNOCOWIFS$minyear1[masterGWNOCOWIFS$gwno == 365] <- 1990
masterGWNOCOWIFS <- rbind(masterGWNOCOWIFS, russiaIFS)

#We decided to give 315 an IFS abbreviation of CZK
masterGWNOCOWIFS$ifs[masterGWNOCOWIFS$gwno == 315] <- "CZK"

sunIFS <- subset(masterGWNOCOWIFS, (masterGWNOCOWIFS$gwno == 355))
sunIFS$maxyear1 <- 1989
sunIFS$ifs <- "SUN"
masterGWNOCOWIFS$minyear1[masterGWNOCOWIFS$gwno == 355] <- 1990
masterGWNOCOWIFS <- rbind(masterGWNOCOWIFS, sunIFS)

save(masterGWNOCOWIFS, file = "/Users/rohitmadan/Google Drive/Master IPE Data/R Conversion Reference/merge_GWNOIFSCOW_RM/masterGWNOCOWIFS_v2.RDATA")







