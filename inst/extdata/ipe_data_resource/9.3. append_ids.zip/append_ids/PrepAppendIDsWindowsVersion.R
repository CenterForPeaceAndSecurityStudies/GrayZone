load(paste(rawdata,"CountryIDsMaster.RDATA",sep=""))
ids = ids[order(ids$country,ids$minyear1,ids$minyear2,ids$maxyear1,ids$maxyear2),]
save(ids,file=paste(rawdata,"CountryIDsMaster_windows.RDATA",sep=""))