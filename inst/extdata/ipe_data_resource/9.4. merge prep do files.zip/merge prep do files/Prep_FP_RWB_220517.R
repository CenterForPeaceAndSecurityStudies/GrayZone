# /************************* 
# Data: Reporters Without Borders: Freedom of the Press [FP]
# Data source url: https://rsf.org/en/ranking_table?sort=asc&order=Country
# Codebook url: https://rsf.org/en/detailed-methodology

# Time:2012-2016	
# By: Sherry
# Suffix: FP
# 
# Citation:
# Reporters Without Borders. 2017. "World Press Freedom Index". 
# https://rsf.org/en/ranking_table Accessed on May 22, 2017


# *************************/

library(foreign)
library(Hmisc)
library(plyr)
library(readxl)
library(reshape)
library(dplyr)


# Read the excel file that contains year 2012- 2014
FP1 <-read_excel(paste(rawdata,"RAWDATA_FP_RWB_1.xlsx",sep=""))

FP1 = FP1[, c("name", "an2012", "sco2013", "an2013","sco2014", "an2014")]


names(FP1)[names(FP1)=="an2014"] = "2014 Rank"
names(FP1)[names(FP1)=="an2013"] = "2013 Rank"
names(FP1)[names(FP1)=="an2012"] = "2012 Rank"
names(FP1)[names(FP1)=="sco2014"] = "2014 Score"
names(FP1)[names(FP1)=="sco2013"] = "2013 Score"

# Order by Name alphabetically
FP1 <- FP1[order(FP1$name),]


# Read the csv file that contains year 2015 - 2016
FP2 <-read.csv(paste(rawdata,"RAWDATA_FP_RWB_2.csv",sep=""),header=TRUE, stringsAsFactors=FALSE)
FP2 = FP2[, c("EN_country", "Score.2015", "Rank.2015", "Overall.Score.2016", "Rank")]

names(FP2)[names(FP2)=="EN_country"] = "name"
names(FP2)[names(FP2)=="Rank"] = "2016 Rank"
names(FP2)[names(FP2)=="Overall.Score.2016"] = "2016 Score"
names(FP2)[names(FP2)=="Score.2015"] = "2015 Score"
names(FP2)[names(FP2)=="Rank.2015"] = "2015 Rank"

# Order by Name alphabetically
FP2 <- FP2[order(FP2$name),]

# Merge two sheets FP1 and FP2
FP <- merge(FP1, FP2, all=TRUE, stringsAsFactors = FALSE)
FP[is.na(FP)] <- NA

# Add an empty column of 2012 Score to get proper reshape format
FP[,"2012 Score"] <- NA

FP <- FP[, c('name', '2012 Score', '2012 Rank', '2013 Score', '2013 Rank', '2014 Score', '2014 Rank',
             '2015 Score', '2015 Rank', '2016 Score', '2016 Rank')]

FP <- reshape(FP, direction='long', 
                 varying=c('2012 Score', '2012 Rank', '2013 Score', '2013 Rank', '2014 Score', '2014 Rank',
                           '2015 Score', '2015 Rank', '2016 Score', '2016 Rank'), 
                 timevar='year',
                 times=c('2012','2013','2014','2015','2016'),
                 v.names=c('score', 'rank'),
                 idvar='name')

FP <- FP[order(FP$name),]


# Rename the columns to the correct ones
names(FP)[names(FP)=="score"] = "Rank"
names(FP)[names(FP)=="rank"] = "Score"
names(FP)[names(FP)=="name"] = "Country"


# Change empty entries to .
FP$Rank[FP$Rank=="-"] = NA
FP$Rank[FP$Rank=="92 - 133"] = "92"


# Rename country names with special character that R cannot recognize
FP$Country[FP$Country=="C\xf4te d'Ivoire"] = "Cote dIvoire"


#Get rid of additional attributes
row.names(FP) <- NULL

FP = append_ids(FP)

backup <- FP



FP <- backup

#Check for Duplicates
n_occur <- data.frame(table(FP$country, FP$year))
print(n_occur[n_occur$Freq > 1,])

# --- Drop the duplicates
# Tanzania Duplicates
FP = FP[-which(FP$countryname_raw == "Tanzania" & FP$year <= 2014),]
FP = FP[-which(FP$countryname_raw == "United Republic Of Tanzania" & FP$year >= 2015),]

# Congo Duplicates
FP = FP[-which(FP$countryname_raw == "Congo" & FP$year <= 2014),]
FP = FP[-which(FP$countryname_raw == "Republic of the Congo" & FP$year >= 2015),]

# Korea Duplicates
FP = FP[-which(FP$countryname_raw == "South Korea"  & FP$year <= 2014),]
FP = FP[-which(FP$countryname_raw == "Republic of Korea" & FP$year >= 2015),]

# Moldova Duplicates
FP = FP[-which(FP$countryname_raw == "Moldova" & FP$year <= 2014),]
FP = FP[-which(FP$countryname_raw == "Republic of Moldova" & FP$year >= 2015),]

# East Timor Duplicates
FP = FP[-which(FP$countryname_raw == "East Timor" & FP$year <= 2014),]
FP = FP[-which(FP$countryname_raw == "Timor-Leste" & FP$year >= 2015),]

# Cote D’Ivoire Duplicates
FP = FP[-which(FP$countryname_raw == "Ivory Coast" & FP$year <= 2014),]
FP = FP[-which(FP$countryname_raw == "CÃ´te d'Ivoire" & FP$year >= 2015),]

# Central African Republic Duplicates
FP = FP[-which(FP$countryname_raw == "Central African Republic" & FP$year <= 2014),]
FP = FP[-which(FP$countryname_raw == "Central African" & FP$year >= 2015),]



# Add variable labels
label(FP$Rank) <- "Reporters without Borders Press Freedom Annual Ranking [FP]"
label(FP$Score) <- "Reporters with Borders Press Freedom Score [FP]"

# Append suffix FP to vairables
FP = append_suffix(FP,"FP")

save(FP,file=paste(preppeddata,"PREPPED_FP_SW_052317.RDATA",sep=""))




