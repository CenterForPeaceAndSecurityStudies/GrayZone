# /************************* 
# Source: Research and expertise on the world economy  
# Accessed: May 24, 2017
# URL(Dist):  http://www.cepii.fr/cepii/en/bdd_modele/presentation.asp?id=6
# URL(English): http://www.cepii.fr/cepii/en/bdd_modele/presentation.asp?id=19
# Query specifications: all countries, all years, variables: english_off_CE, dist_US_CE
# Time: 1800-2015
# By: Jessica Xu
# Suffix: CE
# Variables: english_off_CE: Official Language of the Country is English [CEPPI], dist_US_CE:Distance from US (km between most populous cities) [CEPPI]
# *************************/
library(foreign)
library(readxl)
library(tidyr)
library(dplyr)
library(readstata13)
library(Hmisc)

#import
Dist_US_CE <- read.dta13(paste(rawdata, "/RAWDATA_Dist_US_CE.dta", sep = ""))
English_off_CE <- read.dta13(paste(rawdata, "/RAWDATA_English_off_CE.dta", sep = ""))

#renaming variables
names(Dist_US_CE)[names(Dist_US_CE)=="iso_o"]="Country"
names(Dist_US_CE)[names(Dist_US_CE)=="dist"] = "dist_US"
names(English_off_CE)[names(English_off_CE)=="iso_o"] = "Country"
names(English_off_CE)[names(English_off_CE)=="col"]="english_off"
#keep specific rows
Dist_US_CE = Dist_US_CE[grepl('USA', Dist_US_CE$Country),]
English_off_CE = English_off_CE[grepl('USA', English_off_CE$Country),]
#Keep only the variables we need
Dist_US_CE = Dist_US_CE[, c("Country","iso_d",
            "dist_US")]
English_off_CE= English_off_CE[,c("Country", "iso_d","english_off")]
#merge 
CE<- merge (Dist_US_CE, English_off_CE, by=c("Country","iso_d"))


#Keep only the variables we need
CE = CE[, c("iso_d",
            "dist_US",
            "english_off")]

#renaming variables
names(CE)[names(CE)=="iso_d"]="Country"


#appending gwnos
CE = append_ids(CE)

# Merge gwno and year
load(paste(rawdata, "Country_GWNO_Year_Simple.RDATA", sep = ""))
CE <- merge(CE,simpleCY, by=c("gwno"), all = TRUE)


# Remove rows with empty country entries
CE <- CE[!rowSums(is.na(CE["country"])),]


# Add variable labels
label(CE$english_off) = "Official Language of the Country is English [CE]"
label(CE$dist_US) = "Distance from US (km between most populous cities) [CE]"


#append suffix
CE = append_suffix(CE, "CE")

length(unique(CE$gwno))  #167
range(CE$year) #1816-2017


save(CE,file=paste(preppeddata,"PREPPED_CE_JX_240517.RDATA",sep=""))
