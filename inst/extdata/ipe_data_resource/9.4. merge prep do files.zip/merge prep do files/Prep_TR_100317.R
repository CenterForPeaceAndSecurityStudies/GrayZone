# /**************************
# Data: The trilemma indexes
# Dataset: Aizenman, Chinn, and Ito
# Data source url: http://web.pdx.edu/~ito/trilemma_indexes.htm
# Codebook url: http://web.pdx.edu/~ito/ReadMe_trilemma_indexes2014.pdf
# Time: 1960-2014
# Updated: 2017.02.07
# By: Sherry
# Suffix: TR
# 
# Citation:
#   Aizenman, Joshua, Menzie D. Chinn, and Hiro Ito (2010). "The Emerging Global Financial 
# Architecture: Tracing and Evaluating the New Patterns of the Trilemma's Configurations", 
# Journal of International Money and Finance, Vol. 29, No. 4, p. 615–641.
# 
#   Aizenman, Joshua, Menzie D. Chinn, and Hiro Ito (2013). "The 'Impossible Trinity' Hypothesis 
# in an Era of Global Imbalances: Measurement and Testing," 
# Review of International Economics, 21(3), 447–458(August 2013).

# #****************************/
library(foreign)
library(Hmisc)

tr = read.dta(paste(rawdata,"RAWDATA_TR_2016_Aizenman.dta",sep=""))

#Keep all variables
#Rename some variables
names(tr)[names(tr)=="country_name"] = "country"

# Append country ID not recognize the "?"
tr$country[tr$country=="S? Tom\xb7and Principe"] = "Sao Tome and Principe"

# Number of unique countries and observations
length(unique(tr$country)) #197
length(tr$country) #10831

#Append country IDs
tr = append_ids(tr)

# Number of countries and observations after cleaning
length(unique(tr$country)) #189
length(tr$country) #10281

#Drop the "cn" variable 
tr$cn <- NULL


#Add variable labels
label(tr$ers) <- "Exchange Rate Stability Index [TR]"
label(tr$mi) <- "Monetary Independence Index [TR]"
label(tr$ka_open) <- "Financial Openness Index [TR]"

# Append suffix TR to vairables 
tr = append_suffix(tr,"TR")


save(tr,file=paste(preppeddata,"PREPPED_TR_SW_031017.RDATA",sep=""))

     
     