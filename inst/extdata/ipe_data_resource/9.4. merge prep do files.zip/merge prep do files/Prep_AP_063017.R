# /************************* 
# Change Figi to Fiji
# Archipelagos Data [AP]
# *************************/

library(foreign)
library(Hmisc)
library(readstata13)



# Read the dta file from prepped data folder
AP <-read.dta13(paste(rawdata,"archipelagos.dta", sep=""))

# Change Figi -> Fiji
AP$country[AP$country == "Figi"] <- "Fiji"

# Drop gwno>1000
AP <- AP[!AP$gwno >= 1100, ]

# Drop gwno == 730 & year > 1910
AP = AP[-which(AP$gwno == 730 & AP$year > 1947),]
AP = AP[-which(AP$gwno == 732 & AP$year < 1948),]
AP = AP[-which(AP$gwno == 731 & AP$year < 1948),]

#renaming variables
names(AP)[names(AP)=="lnislands"]="lnislands_AP"

# Add variable labels
label(AP$lnislands_AP) = "Number of islands (ppl > 100000) logged [Archipelagos]"
label(AP$archipelago_AP) = "At least two islands"
label(AP$comments_AP) = "List of the islands in each country"
label(AP$numislands_AP) = "Number of Islands (ppl > 100000)"



length(unique(AP$gwno)) #223
range(AP$year) #1800-2015

save(AP,file=paste(preppeddata,"PREPPED_AP_SW_063017.RDATA",sep=""))



