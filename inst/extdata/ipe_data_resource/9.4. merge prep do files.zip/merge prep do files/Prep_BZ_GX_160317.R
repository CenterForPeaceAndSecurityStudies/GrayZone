# /************************* 
# Source: World Bank Doing Business Indicators
# Accessed: March 16, 2017
# URL: http://www.doingbusiness.org/Custom-Query
# Query: all economies, all topics, all years
# 
# Time: 2004-2017
# Coded by: Grace Xu
# Suffix: BZ
# *************************/

library(readxl)
library(plyr)
library(Hmisc)

#importing raw data
bz = read_excel(paste(rawdata, "RAWDATA_BZ.xlsx", sep=""))

colnames <- colnames(bz)
colnames
#rename variables, included suffix because it was quicker than using append_suffix
bz = rename(bz, c("Economy" = "Country"))
bz = rename(bz, c("Rank" = "rank_BZ"))
bz = rename(bz, c("Starting a business-Rank" = "rank_sb_BZ"))	 
bz = rename(bz, c("Starting a Business - Procedure – Men (number)" = "sb_proc_BZ"))
bz = rename(bz, c("Starting a Business - Time – Men (days)" = "sb_time_BZ"))
bz = rename(bz, c("Starting a Business - Cost – Men (% of income per capita)" = "sb_cost_BZ"))
bz = rename(bz, c("Starting a Business - Paid-in min. capital (% of income per capita)" = "sb_paid_BZ"))
bz = rename(bz, c("Dealing with Construction Permits-Rank" = "rank_cp_BZ"))
bz = rename(bz, c("Dealing with Construction Permits - Procedures (number)" = "cp_proc_BZ"))
bz = rename(bz, c("Dealing with Construction Permits - Time (days)" = "cp_time_BZ"))
bz = rename(bz, c("Dealing with Construction Permits - Cost (% of warehouse value)" = "cp_cost_BZ"))
bz = rename(bz, c("Getting Electricity-Rank" = "rank_ge_BZ"))
bz = rename(bz, c("Getting Electricity - Procedures (number)" = "ge_proc_BZ"))
bz = rename(bz, c("Getting Electricity - Time (days)" = "ge_time_BZ"))
bz = rename(bz, c("Getting Electricity - Cost (% of income per capita)" = "ge_cost_BZ"))
bz = rename(bz, c("Registering Property-Rank" = "rank_rp_BZ"))
bz = rename(bz, c("Registering Property - Procedures (number)" = "rp_proc_BZ"))
bz = rename(bz, c("Registering Property - Time (days)" = "rp_time_BZ"))
bz = rename(bz, c("Registering Property - Cost (% of property value)" = "rp_cost_BZ"))
bz = rename(bz, c("Getting Credit-Rank" = "rank_gc_BZ"))
bz = rename(bz, c("Getting Credit - Strength of legal rights index (0-12)" = "gc_legal_BZ"))
bz = rename(bz, c("Getting Credit - Strength of legal rights index (0-10) old methodology" = "gc_legal_old_BZ"))
bz = rename(bz, c("Getting Credit - Depth of credit information index (0-8)" = "gc_info_BZ"))
bz = rename(bz, c("Getting Credit - Depth of credit information index (0-6) old methodology" = "gc_info_old_BZ"))
bz = rename(bz, c("Getting Credit - Credit registry coverage (% of adults)" = "gc_pub_BZ"))
bz = rename(bz, c("Getting Credit - Credit bureau coverage (% of adults)" = "gc_priv_BZ"))
bz = rename(bz, c("Protecting Minority Investors-Rank" = "rank_pi_BZ"))
bz = rename(bz, c("Protecting Minority Investors - Extent of disclosure index (0-10)" = "pi_disc_BZ"))
bz = rename(bz, c("Protecting Minority Investors - Extent of director liability index (0-10)" = "pi_dl_BZ"))
bz = rename(bz, c("Protecting Minority Investors - Ease of shareholder suits index (0-10)" = "pi_shsu_BZ"))
bz = rename(bz, c("Protecting Minority Investors - Ease of shareholder suits index (0-10) old methodology" = "pi_shsu_old_BZ"))
bz = rename(bz, c("Protecting Minority Investors - Strength of minority investor protection index (0-10)" = "pi_ip_BZ"))
bz = rename(bz, c("Protecting Minority Investors - Strength of investor protection index (0-10) old methodology" = "pi_ip_old_BZ"))
bz = rename(bz, c("Paying Taxes-Rank" = "rank_pt_BZ"))
bz = rename(bz, c("Paying Taxes - Payments (number per year)" = "pt_pay_BZ"))
bz = rename(bz, c("Paying Taxes - Time (hours per year)" = "pt_time_BZ"))
bz = rename(bz, c("Paying Taxes - Profit tax (% of profit)" = "pt_prof_BZ"))
bz = rename(bz, c("Paying Taxes - Labor tax and contributions (% of profit)" = "pt_lab_BZ"))
bz = rename(bz, c("Paying Taxes - Other taxes (% of profit)" = "pt_other_BZ"))
bz = rename(bz, c("Paying Taxes - Total tax rate (% of profit)" = "pt_tot_BZ"))
bz = rename(bz, c("Trading Across Borders-Rank" = "rank_tr_BZ"))
bz = rename(bz, c("Trading across Borders - Documents to export (number) old methodology" = "tr_exdo_old_BZ"))
bz = rename(bz, c("Trading across Borders - Time to export (days) old methodology" = "tr_exti_old_BZ"))
bz = rename(bz, c("Trading across Borders - Cost to export (US$ per container) old methodology" = "tr_exco_old_BZ"))
bz = rename(bz, c("Trading across Borders - Documents to import (number) old methodology" = "tr_imdo_BZ"))
bz = rename(bz, c("Trading across Borders - Time to import (days) old methodology" = "tr_imti_old_BZ"))
bz = rename(bz, c("Trading across Borders - Cost to import (US$ per container) old methodology" = "tr_imco_old_BZ"))
bz = rename(bz, c("Enforcing Contracts-Rank" = "rank_ec_BZ"))
bz = rename(bz, c("Enforcing Contracts - Time (days)" = "ec_time_BZ"))
bz = rename(bz, c("Enforcing Contracts - Cost (% of claim)" = "ec_cost_BZ"))
bz = rename(bz, c("Resolving Insolvency-Rank" = "rank_ri_BZ"))
bz = rename(bz, c("Resolving Insolvency - Time (years)" = "ri_time_BZ"))
bz = rename(bz, c("Resolving Insolvency - Cost (% of estate)" = "ri_cost_BZ"))
bz = rename(bz, c("Resolving Insolvency - Outcome (0 as piecemeal sale and 1 as going concern)" = "ri_out_BZ"))
bz = rename(bz, c("Resolving Insolvency - Recovery rate (cents on the dollar)" = "ri_reco_BZ"))

#getting rid of columns we don't need
columns = c(1,2, grep("_BZ", colnames(bz)))
bz = bz[,columns]

#getting rid of "DB" in the years
bz$Year = gsub('DB','', bz$Year)

#change columns to numerics and standardize missing variables 'no practice' to NAs
for(i in 2:ncol(bz)){
  bz[[i]] = as.numeric(bz[[i]])
}

#label variables
label(bz$rank_BZ) = "Ease of Doing Business Rank [WB_Biz]"
label(bz$rank_sb_BZ) = "Starting a Business Rank [WB_Biz]"
label(bz$sb_proc_BZ) = "Starting a business, procedures (number) [WB_Biz]"
label(bz$sb_time_BZ) = "Starting a business, time (days) [WB_Biz]"
label(bz$sb_cost_BZ) = "Starting a business, cost (% of income percapita) [WB_Biz]"
label(bz$sb_paid_BZ) = "Starting a business, paid in min. cap (% of income per capita) [WB_Biz]"
label(bz$rank_cp_BZ) = "Dealing with Construction Permits Rank [WB_Biz]"
label(bz$cp_proc_BZ) = "Dealing with Construction Permits, procedures (number) [WB_Biz]"
label(bz$cp_time_BZ) = "Dealing with Construction Permits, time (days) [WB_Biz]"
label(bz$cp_cost_BZ) = "Dealing with Construction Permits, cost (% of warehouse value) [WB_Biz]"
label(bz$rank_ge_BZ) = "Getting Electricity Rank [WB_Biz]"
label(bz$ge_proc_BZ) = "Getting Electricity, procedures (number) [WB_Biz]"
label(bz$ge_time_BZ) = "Getting Electricity, time (days) [WB_Biz]"
label(bz$ge_cost_BZ) = "Getting Electricity, cost (% of income per capita) [WB_Biz]"
label(bz$rank_rp_BZ) = "Registering Property Rank [WB_Biz]"
label(bz$rp_proc_BZ) = "Registering Property, procedures (number) [WB_Biz]"
label(bz$rp_time_BZ) = "Registering Property, time (days) [WB_Biz]"
label(bz$rp_cost_BZ) = "Registering Property, cost (% of property value) [WB_Biz]"
label(bz$rank_gc_BZ) = "Getting Credit Rank [WB_Biz]"
label(bz$gc_legal_BZ) = "Getting Credit, strength of legal rights index (0-12) [WB_Biz]"
label(bz$gc_legal_old_BZ) = "Getting Credit, strength of legal rights index (0-10) old methodology [WB_Biz]"
label(bz$gc_info_BZ) = "Getting Credit, depth of credit information index (0-8) [WB_Biz]"
label(bz$gc_info_old_BZ) = "Getting Credit, depth of credit information index (0-6) old methodology [WB_Biz]"
label(bz$gc_pub_BZ) = "Getting Credit, public registry coverage (% of adults) [WB_Biz]"
label(bz$gc_priv_BZ) = "Getting Credit, private bureau coverage (% of adults) [WB_Biz]"
label(bz$rank_pi_BZ) = "Protecting Minority Investors Rank [WB_Biz]"
label(bz$pi_disc_BZ) = "Protecting Minority Investors, extent of disclosure index (0-10) [WB_Biz]"
label(bz$pi_dl_BZ) = "Protecting Minority Investors, extent of director liability index (0-10) [WB_Biz]"
label(bz$pi_shsu_BZ) = "Protecting Minority Investors, ease of shareholder suits index (0-10) [WB_Biz]"
label(bz$pi_shsu_old_BZ) = "Protecting Minority Investors, ease of shareholder suits index (0-10) old methodology [WB_Biz]"
label(bz$pi_ip_BZ) = "Protecting Minority Investors, strength of investor protection index (0-10) [WB_Biz]"
label(bz$pi_ip_old_BZ) = "Protecting Minority Investors, strength of investor protection index (0-10) old methodology [WB_Biz]"
label(bz$rank_pt_BZ) = "Paying Taxes Rank [WB_Biz]"
label(bz$pt_pay_BZ) = "Paying Taxes, payments (number per year) [WB_Biz]"
label(bz$pt_time_BZ) = "Paying Taxes, time (hours per year) [WB_Biz]"
label(bz$pt_prof_BZ) = "Paying Taxes, profit tax (%) [WB_Biz]"
label(bz$pt_lab_BZ) = "Paying Taxes, labor tax and contributions (%) [WB_Biz]"
label(bz$pt_other_BZ) = "Paying Taxes, other taxes (%) [WB_Biz]"
label(bz$pt_tot_BZ) = "Paying Taxes, total tax rate (% profit) [WB_Biz]"
label(bz$rank_tr_BZ) = "Trading Across Borders Rank [WB_Biz]"
label(bz$tr_exdo_old_BZ) = "Trading Across Borders, documents to export (number) old methodology [WB_Biz]"
label(bz$tr_exti_old_BZ) = "Trading Across Borders, time to export (days) old methodology [WB_Biz]"
label(bz$tr_exco_old_BZ) = "Trading Across Borders, cost to export (number) old methodology [WB_Biz]"
label(bz$rank_tr_BZ) = "Trading Across Borders, cost to export (US$ per container) [WB_Biz]"
label(bz$tr_imdo_BZ) = "Trading Across Borders, documents to import (number) [WB_Biz]"
label(bz$tr_imti_old_BZ) = "Trading Across Borders, time to import (days) [WB_Biz]"
label(bz$tr_imco_old_BZ) = "Trading Across Borders, cost to import (US$ per container) [WB_Biz]"
label(bz$rank_ec_BZ) = "Enforcing Contracts Rank [WB_Biz]"
label(bz$ec_time_BZ) = "Enforcing Contracts, time (days) [WB_Biz]"
label(bz$ec_cost_BZ) = "Enforcing Contracts, cost (% of claim) [WB_Biz]"
label(bz$rank_ri_BZ) = "Resolving Insolvency Rank [WB_Biz]"
label(bz$ri_time_BZ) = "Resolving Insolvency, time (years) [WB_Biz]"
label(bz$ri_cost_BZ) = "Resolving Insolvency, cost (% of estate) [WB_Biz]"
label(bz$ri_out_BZ) = "Resolving Insolvency, outcome (0 as piecemeal sale and 1 as going concern) [WB_Biz]"
label(bz$ri_reco_BZ) = "Resolving Insolvency, recovery rate (cents on the dollar) [WB_Biz]"

#appending IDs
bz = append_ids(bz)

bz = rename(bz, c("countryname_raw" = "countryname_raw_BZ"))
label(bz$countryname_raw_BZ) = "Original Country Name in dataset BZ"

############ Testing ################
labels <- label(bz)
colnames <- colnames(bz)
size <- length(colnames)

# All Colnames and Labels
AA <- data.frame(matrix(ncol = 0, nrow = size))
AA$colNames <- colnames
AA$labels <- labels

# Empty Labels
AB<-AA[(AA$labels == ""),]



#save
save(bz,file=paste(preppeddata,"prepped_bz.RDATA",sep=""))
