# /************************* 
# Source: Organization for Economic Cooperation and Development. Program for International Student Assesment. 
# Accessed: May 20, 2017
# URL: http://pisadataexplorer.oecd.org/ide/idepisa/report.aspx
# 
# Time: 2000, 2003, 2006, 2009, 2012, 2015
# Coded by: Grace Xu
# Suffix: PIS
# Variables: math_avg, reading_avg, science_avg
# *************************/

library(readxl)
library(Hmisc)

math = read_excel(paste(rawdata,"RAWDATA_PIS_2015.xls", sep = ""), col_names=FALSE)
reading = read_excel(paste(rawdata,"RAWDATA_PIS_2015.xls", sep = ""), sheet = 2, col_names=FALSE)
science = read_excel(paste(rawdata,"RAWDATA_PIS_2015.xls", sep = ""), sheet = 3, col_names=FALSE)

math = math[rowSums(is.na(math))!=4, ]
reading = reading[rowSums(is.na(reading))!=4, ]
science = science[rowSums(is.na(science))!=4, ]

#standardize datasets to match each other
math = math[6:216,1:3]
math[1,3] = "Math"
reading = reading[6:216,1:3]
reading[1,3] = "Reading"
science = science[6:216,1:3]
science[1,3] = "Science"

#combine the 3 datasets
pis = cbind(math, reading, science)
remove(math)
remove(reading)
remove(science)

#making headers
colnames(pis) = pis[1,]
pis = pis[-c(1),]

#renaming variables
names(pis)[names(pis)=="Jurisdiction"] = "Country"
names(pis)[names(pis)=="Math"] = "math_avg"
names(pis)[names(pis)=="Reading"] = "reading_avg"
names(pis)[names(pis)=="Science"] = "science_avg"

#keeping only the variables we need
pis = pis[,c("Year", "Country", "math_avg", "reading_avg", "science_avg")]

#filling in year for every row
for(x in c(1:nrow(pis))){
  if (!is.na(pis[x,1])){
    year = pis[x,1]
  }else{
    pis[x,1] = year
  }
}

#removing code and just replacing "Not available", "Not applicable." and "Reporting standards not met." with NA
pis$Year = as.numeric(pis$Year)
pis$'math_avg' = as.numeric(pis$'math_avg')
pis$'reading_avg' = as.numeric(pis$'reading_avg')
pis$'science_avg' = as.numeric(pis$'science_avg')

label(pis$'math_avg') = "Average mathematics scores [PIS]"
label(pis$'reading_avg') = "Average reading scores [PIS]"
label(pis$'science_avg') = "Average science scores [PIS]"

# Change country name Korea into South Korea
pis$Country[pis$Country=="Korea"] = "South Korea"

pis = append_ids(pis)
pis = append_suffix(pis, "PIS")

#save
save(pis, file = paste(preppeddata, "PREPPED_PIS_GX_200517.RDATA", sep=""))
