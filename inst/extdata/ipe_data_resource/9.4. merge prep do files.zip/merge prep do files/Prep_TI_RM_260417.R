###############################
# Transparency International Corruption Perceptions Index [TI]
# Version: 2016
# Accessed: April 26, 2017
# Year Range: 1995-2016
# Prepped By: Rohit Madan
# Suffix: TI
# Last update: 04/26/2017
#
# Data: http://www.transparency.org/permissions/#datasets
# 
#
# Citation: Transparency International. 2016."Corruption Perceptions Index 2016." 
# http://www.transparency.org/permissions/#datasets. Accessed on April 26, 2016.
#
# Variables: ti_cpi_TI, Label: "Corruption perceptions index [TI]"
#
# Note: This code updates the data from 1995-2014 in the current version of the IPE to 1995-2016.
# Note: Methodology changes after 2012. Scores go from 0-10 to 0-100. 
# 
###############################

library(readxl)

#Read raw data 
ti = read_excel(path = (paste(rawdata, "RAWDATA_TI_2016_TransparencyInternational.xlsx", sep="")), sheet = "CPI 1995-2015", skip = 4)

ti <- ti[-c(1), ]

varsToKeep <- c("Country/Territory", "2016 CPI Score", "2015 CPI Score", "2014 CPI Score", "2013 CPI Score", "2012 CPI Score", "2011 CPI Score", "2010 CPI Score", "1999 CPI Score", "1998 CPI Score", "1997 CPI Score", "1996 CPI Score", "1995 CPI Score")
ti <- ti[varsToKeep]
#Change variable names to make reshape possible
names(ti)[names(ti)=="2016 CPI Score"] <- "2016"
names(ti)[names(ti)=="2015 CPI Score"] <- "2015"
names(ti)[names(ti)=="2014 CPI Score"] <- "2014"
names(ti)[names(ti)=="2013 CPI Score"] <- "2013"
names(ti)[names(ti)=="2012 CPI Score"] <- "2012"
names(ti)[names(ti)=="2011 CPI Score"] <- "2011"
names(ti)[names(ti)=="2010 CPI Score"] <- "2010"
names(ti)[names(ti)=="1999 CPI Score"] <- "1999"
names(ti)[names(ti)=="1998 CPI Score"] <- "1998"
names(ti)[names(ti)=="1997 CPI Score"] <- "1997"
names(ti)[names(ti)=="1996 CPI Score"] <- "1996"
names(ti)[names(ti)=="1995 CPI Score"] <- "1995"


library(reshape2)
#Reshape
# Specify id.vars: the variables to keep but not split apart on
ti <- melt(ti, id.vars=c("Country/Territory"))

#Change names
#Change name of variable
names(ti)[names(ti)=="Country/Territory"] <- "Country"
names(ti)[names(ti)=="variable"] <- "year"
names(ti)[names(ti)=="value"] <- "ti_cpi"

#cast to int
ti$year <- as.numeric(as.character(ti$year))
ti$ti_cpi <- as.numeric(as.character(ti$ti_cpi))

backup <- ti
ti <- backup

sum(is.na(ti$Country))
#Remove missing countries
#ti <- ti[-which(is.na(ti$Country)), ]

#Append ids
ti <- append_ids(ti, breaks = T)


#Check for Duplicates
n_occur <- data.frame(table(ti$country, ti$year))
print(n_occur[n_occur$Freq > 1,])

# --- Drop the duplicates
# Serbia Duplicates
ti = ti[-which(ti$countryname_raw == "Yugoslavia" & ti$year >= 2010),]
ti = ti[-which(ti$countryname_raw == "Serbia" & ti$year >= 1995 & ti$year < 2010),]



## Append Suffix
ti <- append_suffix(ti, "TI")

#Label
library(Hmisc)
label(ti$ti_cpi_TI) <- "Corruption perceptions index [TI]" 

#save prepped data
save(ti,file=paste(preppeddata,"PREPPED_TI_RM_260417.RDATA",sep=""))



