###############################
# Source: Stockholm Peace Research Institute (SIPRI)
# Accessed: February 28, 2017
# URL: https://www.sipri.org/databases/milex
# Year Range: 1949-2015 (variable)
# Prepped By: Rohit Madan
# Suffix SI
#   
# Citation:
# Stockholm International Peace Research Institute. SIPRI Military Expenditure Database 2016. 
# https://www.sipri.org/databases/milex. Accessed on February 28, 2017.
###############################

library(foreign)
library(Hmisc)
library(readxl)
library(reshape)
#Read raw data
si = read_excel(path = (paste(rawdata, "RAWDATA_SI_2016_SIPRI.xlsx", sep="")), sheet = "Constant (2014) USD", skip = 5)

#Keep needed variables
yearsToKeep <- paste(1949:2015, sep="")

varsToKeep <- c("Country", yearsToKeep)
si <- si[varsToKeep]
si <- si[-(192:379),]

#standardize missing data
si[si == "xxx"] <- NA
si[si == ". ."] <- NA

# Change si tibble to a dataframe
si <- as.data.frame(si)

#reshape
#si = melt(si,id="Country",variable_name="year")
si <- reshape(as.data.frame(si), direction = "long", varying = yearsToKeep, v.names = "milex", idvar=c("Country"), timevar="Year", times=1949:2015)

#Get rid of additional attributes
row.names(si) <- NULL

#Append country IDs
si = append_ids(si)


#Append Suffix
si = append_suffix(si,"SI")


backup <- si

si <- backup

#Check for Duplicates
n_occur <- data.frame(table(si$country, si$year))
print(n_occur[n_occur$Freq > 1,])

# --- Drop the duplicates
# Yemen Duplicates
si = si[-which(si$countryname_raw_SI == "Yemen" & si$year < 1990),]
si = si[-which(si$countryname_raw_SI == "Yemen, North" & si$year >= 1990),]

# Serbia Duplicates
si = si[-which(si$countryname_raw_SI == "Yugoslavia (former)"),]

# Russia Duplicates
si = si[-which(si$countryname_raw_SI == "Russian Federation" & si$year <= 1991),]
si = si[-which(si$countryname_raw_SI == "USSR" & si$year > 1991),]

# Czech Republic Duplicates
si = si[-which(si$countryname_raw_SI == "Czech Rep." & si$year <= 1992),]
si = si[-which(si$countryname_raw_SI == "Czechoslovakia" & si$year > 1992),]

library(Hmisc)
label(si$milex_SI) <- "Military Expenditures (SIPRI) in millions (2011 USD) [SI]"

length(unique(si$gwno)) #172
range(si$year) #1949 - 2015

#Save file
save(si,file=paste(preppeddata,"PREPPED_SI_RM_031317.RDATA",sep=""))
