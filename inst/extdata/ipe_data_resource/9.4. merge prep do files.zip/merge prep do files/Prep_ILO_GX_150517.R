# /************************* 
# Source: The International Labor Organization
# Accessed: May 15th, 2017
# URL: http://www.ilo.org/ilostat/faces/oracle/webcenter/portalapp/pagehierarchy/Page27.jspx?subject=EAR&indicator=LAC_XEES_ECO_NB&datasetCode=A&collectionCode=YI&_afrLoop=450386476161074&_afrWindowMode=0&_afrWindowId=o26mf2g7z_356#!%40%40%3Findicator%3DLAC_XEES_ECO_NB%26_afrWindowId%3Do26mf2g7z_356%26subject%3DEAR%26_afrLoop%3D450386476161074%26datasetCode%3DA%26collectionCode%3DYI%26_afrWindowMode%3D0%26_adf.ctrl-state%3Do26mf2g7z_388
# Query: All years, all countries, "Aggregate categories of economic activity: Total"
# 
# Time: 2000-2010
# Coded by: Grace Xu
# Suffix: ILO
# Variables: unitlaborcost_ILO
# *************************/

library(readxl)
library(foreign)
library(Hmisc)
library(tidyr)
library(dplyr)

ilo = read.csv(paste(rawdata, "RAWDATA_ILO_xl.csv", sep = ""), stringsAsFactors = FALSE)

#renaming columns & removing unneccessary ones
colnames(ilo)[1] = "Country"

# Delete rows till Country
ilo <- ilo[!(is.na(ilo$Country) | ilo$Country==""), ]

# Remove all the rows until first column is "Country"
for(x in 1: nrow(ilo)){
  if(ilo[[x,1]] =="Country"){
    break
  }
}

ilo <- ilo[c(x:nrow(ilo)), ]

# adding column headers
colnames(ilo) <- ilo[1,]
# getting rid of headers, as well as end has a lot of blank rows
ilo = ilo[c(-1),]


#Check Duplicates
n_occur <- data.frame(table(ilo$Country))
print(n_occur[n_occur$Freq > 1,])

colToKeep <- 2000:2015
colToKeep <- c("Country", colToKeep)

ilo <- ilo[colToKeep]


# Hungary take average
ilo <- aggregate(ilo[, -c(1)], by = list(ilo$Country), 
          mean, na.rm = TRUE) 

ilo[ilo == "NaN"] = NA



#reshape
ilo = gather(ilo, "year", "unitlaborcost", 2:ncol(ilo))

colnames(ilo)[1] = "Country"

#label
label(ilo$unitlaborcost) <- "Mean nominal hourly labour cost per employee (Local Currency) [ILO]"


 
#append ID and suffixes
ilo = append_ids(ilo)
ilo = append_suffix(ilo, "ILO")

# Number of Countries
length(unique(ilo$gwno))   #48
range(ilo$year) # 2000 - 2015
#save
save(ilo, file = paste(preppeddata, "Prepped_ILO_GX_150517.RDATA", sep=""))
