#/**************************
# Source: Freedom House 
# Dataset: Freedom of the Press 
# Data source url: https://freedomhouse.org/report-types/freedom-press 
# Codebook url: https://freedomhouse.org/report/freedom-press-2016-methodology 
# Time: 1979-2016
# Data download: 2017. 04. 18
# Suffix: fhp
# Notes:
#  Adjustments made for Serbia, Montenegro, Yugoslavia transition
#  at end of file. Has separate observations for Montenegro/Serbia from 2006.
#****************************/

library(Hmisc)
library(readxl)
library(dplyr)
library(stringr)
library(tidyr)

# --- Import dataset
fhp = read_excel(paste(rawdata,"RAWDATA_FHP_2016_FreedomHouse.xlsx", sep=""), 2, col_names = TRUE)

# --- Create variable names
names(fhp)[1] = "country"
names(fhp)[2] = "p_1979"
names(fhp)[3] = "b_1979"
names(fhp)[4] = "p_1980"
names(fhp)[5] = "b_1980"
names(fhp)[6] = "p_1981"
names(fhp)[7] = "b_1981" 
names(fhp)[8] = "p_1982"
names(fhp)[9] = "b_1982"
names(fhp)[10] =	"p_1983"
names(fhp)[11] = "b_1983"
names(fhp)[12] =	"p_1984"
names(fhp)[13] = "b_1984"
names(fhp)[14] =	"p_1985"
names(fhp)[15] = "b_1985"
names(fhp)[16] =	"p_1986"
names(fhp)[17] =	"b_1986"
names(fhp)[18] = "ss_1988"
names(fhp)[19] = "ss_1989"
names(fhp)[20] = "ss_1990"
names(fhp)[21] = "ss_1991"
names(fhp)[22] = "ss_1992"
names(fhp)[23] = "sr_1993"
names(fhp)[24] = "ss_1993"
names(fhp)[25] = "sr_1994"
names(fhp)[26] = "ss_1994"
names(fhp)[27] = "sr_1995"
names(fhp)[28] = "ss_1995"
names(fhp)[29] = "sr_1996"
names(fhp)[30] = "ss_1996"
names(fhp)[31] = "sr_1997"
names(fhp)[32] = "ss_1997"
names(fhp)[33] = "sr_1998"
names(fhp)[34] = "ss_1998"
names(fhp)[35] = "sr_1999"
names(fhp)[36] = "ss_1999"
names(fhp)[37] = "sr_2000"
names(fhp)[38] = "ss_2000"
names(fhp)[39] = "sr_2001"
names(fhp)[40] = "ss_2001"
names(fhp)[41] = "sr_2002"
names(fhp)[42] = "ss_2002"
names(fhp)[43] = "sr_2003"
names(fhp)[44] = "ss_2003"
names(fhp)[45] = "sr_2004"
names(fhp)[46] = "ss_2004"
names(fhp)[47] = "sr_2005"
names(fhp)[48] = "ss_2005"
names(fhp)[49] = "sr_2006"
names(fhp)[50] = "ss_2006"
names(fhp)[51] = "sr_2007"
names(fhp)[52] = "ss_2007"
names(fhp)[53] = "sr_2008"
names(fhp)[54] = "ss_2008"
names(fhp)[55] = "sr_2009"
names(fhp)[56] = "ss_2009"
names(fhp)[57] = "sr_2010"
names(fhp)[58] = "ss_2010"
names(fhp)[59] = "sr_2011"
names(fhp)[60] = "ss_2011"
names(fhp)[61] = "sr_2012"
names(fhp)[62] = "ss_2012"
names(fhp)[63] = "sr_2013"
names(fhp)[64] = "ss_2013"
names(fhp)[65] = "sr_2014"
names(fhp)[66] = "ss_2014"
names(fhp)[67] = "sr_2015"
names(fhp)[68] = "ss_2015"

# --- Delete empty columns
fhp = fhp[,-c(69:196)]

# --- Delete empty rows
fhp = fhp[-c(215:223),]

# --- Delete the first 4 rows, which are column headers
fhp = fhp[-c(1:4),]

# --- Change "N/As" into missing values
fhp[fhp == "N/A"] = NA

# --- Reshape data
fhp = gather(fhp, "year", "value", 2:ncol(fhp))

# --- Split the year variable 
year_ind = str_split_fixed(fhp$year, "_", 2)

fhp$indicator = year_ind[,1]
fhp$year = year_ind[,2]

# --- Separate into four datasets by indicator
print = filter(fhp, indicator == "p")
names(print)[names(print) == "value"] = "p"

broadcast = filter(fhp, indicator == "b")
names(broadcast)[names(broadcast) == "value"] = "b"

status = filter(fhp, indicator == "ss")
names(status)[names(status) == "value"] = "ss"

score = filter(fhp, indicator == "sr")
names(score)[names(score) == "value"] = "sr"

# --- Drop the indicator variable
print = subset(print, select = -c(indicator))
broadcast = subset(broadcast, select = -c(indicator))
status = subset(status, select = -c(indicator))
score = subset(score, select = -c(indicator))

# --- Merge by country-year
fhp = merge(print, broadcast,
           by = c("country", "year"),
           all = TRUE)

fhp = merge(fhp, status,
           by = c("country", "year"),
           all = TRUE)

fhp = merge(fhp, score,
           by = c("country", "year"),
           all = TRUE)

# --- Convert the SR variable to numeric
fhp$sr = as.numeric(fhp$sr)

# --- Relabel values
# NF = not free = 0
# PF = partly free = 1
# F = free = 2
fhp[fhp == "NF"] = 0
fhp[fhp == "PF"] = 1
fhp[fhp == "F"] = 2

# --- Order rows by country-year
fhp = fhp[order(fhp$country, fhp$year),]

# --- Checking for duplicates: no duplicates
n_occur <- data.frame(table(fhp$country, fhp$year))
n_occur[n_occur$Freq > 1,]

# --- Change spelling of Cote dIvoire so the append_ids function picks it up
fhp$country[fhp$country == "C\xf4te d'Ivoire"] = "Cote dIvoire"

# --- Append IDs
fhp = append_ids(fhp)
fhp = append_suffix(fhp, "fhp")

# --- Checking for duplicates: there are many duplicates
n_occur <- data.frame(table(fhp$country, fhp$year))
n_occur[n_occur$Freq > 1,]

# --- Drop the duplicates
# Germany duplicates
fhp = fhp[-which(fhp$countryname_raw_fhp == "Germany, West" & fhp$year >= 1990),]
fhp = fhp[-which(fhp$countryname_raw_fhp == "Germany" & fhp$year <= 1989),]

# Russia duplicates
fhp = fhp[-which(fhp$countryname_raw_fhp == "USSR" & fhp$year >= 1992),]
fhp = fhp[-which(fhp$countryname_raw_fhp == "Russia" & fhp$year <= 1991),]

# Yemen duplicates
fhp = fhp[-which(fhp$countryname_raw_fhp == "Yemen, North" & fhp$year >= 1990),]
fhp = fhp[-which(fhp$countryname_raw_fhp == "Yemen" & fhp$year <= 1989),]

# Czechoslovakia / Czech Republic duplicates
fhp = fhp[-which(fhp$countryname_raw_fhp == "Czechoslovakia" & fhp$year >= 1993),]
fhp = fhp[-which(fhp$countryname_raw_fhp == "Czech Republic" & fhp$year <= 1992),]

# Yugoslavia / Serbia & Montenegro duplicates
fhp = fhp[-which(fhp$countryname_raw_fhp == "Yugoslavia" & fhp$year >= 1993),]
fhp = fhp[-which(fhp$countryname_raw_fhp == "Serbia and Montenegro" & fhp$year <= 1992),]

# Serbia duplicates
fhp = fhp[-which(fhp$countryname_raw_fhp == "Serbia" & fhp$year >= 2007),]
fhp = fhp[-which(fhp$countryname_raw_fhp == "Serbia" & fhp$year >= 1993),]
fhp = fhp[-which(fhp$countryname_raw_fhp == "Serbia" & fhp$year >= 1979),]

# --- Drop the raw country name variable
# fhp = fhp[-c(8)]

# --- Number of countries in the dataset = 200
length(unique(fhp$country))
n_countries = fhp %>%
  group_by(country) %>%
  summarise(n_years = n() ) %>%
  arrange(desc(n_years))
View(n_countries)

# --- Year range
range(fhp$year)

# --- Variable labels
label(fhp$p_fhp) = "Printing press freedom [fhp]"
label(fhp$b_fhp) = "Broadcast press freedom [fhp]"
label(fhp$ss_fhp) = "Free status [fhp]"
label(fhp$sr_fhp) = "Numerical score [fhp]"

# --- Saving prepped data
save(fhp,file=paste(preppeddata,"prepped_FHP_SCM.RDATA",sep=""))
