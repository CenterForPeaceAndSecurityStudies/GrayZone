# /************************* 
# Source: Organisation for Economic Co-operation and Development
# Accessed: March 13, 2017
# URL: http://stats.oecd.org/
# Query specifications: all countries, all years, variables: long term interest rate
# 
# Time: 1954-2016
# By: Grace Xu
# Suffix: OECD
# Variables: Long-term interest rate
# *************************/

library(Hmisc)
library(foreign)

#import
oecd <- read.csv(paste(rawdata, "RAWDATA_OECD_2017.csv", sep=""), stringsAsFactors = FALSE)

# Change Korea -> South Korea
oecd$Country[oecd$Country == "Korea"] <- "South Korea"

#cut out unecessary variables
oecd = oecd[,c("Country",
               "Time",
               "Value")]

#renaming variables
names(oecd)[names(oecd)=="Time"] = "year"
names(oecd)[names(oecd)=="Value"] = "ltint"

#label
label(oecd$ltint) <- "Long-term interest rate (percentage) [OECD]"



#appending gwnos
oecd = append_ids(oecd)

#labels
label(oecd$ltint) = "Long-term interest rate [OECD], percentage"

#append suffix
oecd = append_suffix(oecd, "OECD")

save(oecd,file=paste(preppeddata,"PREPPED_OECD_GX_130317.RDATA",sep=""))
