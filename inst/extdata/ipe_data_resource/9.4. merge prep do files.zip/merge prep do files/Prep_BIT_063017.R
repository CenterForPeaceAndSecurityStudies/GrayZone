# /************************* 
# Change Figi to Fiji
# Archipelagos Data [BIT]
# *************************/

library(foreign)
library(Hmisc)
library(readstata13)


# Read the dta file from prepped data folder
BIT <-read.dta13(paste(rawdata,"Prepped_BITs 1959-2012 merged.dta", sep=""))

# Change Figi -> Fiji
BIT$country[BIT$country == "Figi"] <- "Fiji"

# Drop gwno>1000
BIT <- BIT[!BIT$gwno >= 1100, ]


# Drop gwno == 730 & year > 1910
BIT = BIT[-which(BIT$gwno == 730 & BIT$year > 1947),]
BIT = BIT[-which(BIT$gwno == 732 & BIT$year < 1948),]
BIT = BIT[-which(BIT$gwno == 731 & BIT$year < 1948),]



# Add variable labels
label(BIT$bitstodate_BIT) = "BITs signed to date [BIT]"
label(BIT$lnbitstodate_BIT) = "BITs signed to date (logged) [BIT]"

save(BIT,file=paste(preppeddata,"PREPPED_BIT_SW_063017.RDATA",sep=""))



