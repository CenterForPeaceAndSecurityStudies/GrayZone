# /************************* 
# Data: Worldwide Governance Indicators
# Data source url: http://info.worldbank.org/governance/wgi/#home
# Codebook url: http://info.worldbank.org/governance/wgi/#doc

# Time:1996-2015	
# By: Sherry
# Suffix: WGI
# 
# Citation:
# Kaufmann, Daniel, Aart Kraay, and Massimo Mastruzzi.  2009. 
# "Governance Matters VIII: Aggregate and Individual Governance Indicators, 1996-2008." 
# World Bank Policy Research Working Paper 4978. Available at http://papers.ssrn.com/sol3/papers.cfm?abstract_id=1424591
# 
# Kaufmann, Daniel, Aart Kraay, and Massimo Mastruzzi. 2011. 
# “The Worldwide Governance Indicators: Methodology and Analytical Issues.” 
# Hague Journal on the Rule of Law 3(2): 220–246. doi:10.1017/S1876404511200046.


# *************************/

library(foreign)
library(Hmisc)
library(plyr)
library(readxl)
library(reshape)
#import
wgi <-read.csv(paste(rawdata,"RAWDATA_WGI_2016_Kaufmann.csv",sep=""),header=TRUE, stringsAsFactors=FALSE)

# only keep the estimate value which is Min.Goverance(-2.5 to +2.5)
wgi <- subset(wgi, wgi$Measure.Names == "Min. Governance (-2.5 to +2.5)")

# Order the data by country name
wgi <- wgi[order(wgi$Country),]

# Keep the variable we are interested
wgi = wgi[, c("Country", "Year", "Indicator", "Measure.Values")]

# Reshape the table
wgi <- reshape(wgi, idvar = c("Country", "Year"), timevar = "Indicator", direction = "wide")

sum(is.na(wgi$Country)) #0

# # Number of countries and observations before cleaning
length(unique(wgi$Country))#214
length(wgi$Country) #3547

# Rename the country Cote dIvoire because it has special character that R cannot recognize
wgi$Country[wgi$Country=="C\xf4te d'Ivoire"] = "Cote dIvoire"
wgi$Country[wgi$Country=="R\xe9union"] = "Reunion"
wgi$Country[wgi$Country=="S\xe3o Tom\xe9 and Principe"] = "Sao Tome & Principe"

# Rename Variable Name 
colnames(wgi)[colnames(wgi)=="Measure.Values.Voice and Accountability"] <- "VA_EST"
colnames(wgi)[colnames(wgi)=="Measure.Values.Political Stability and Absence of Violence/Terrorism"] <- "PV_EST"
colnames(wgi)[colnames(wgi)=="Measure.Values.Government Effectiveness"] <- "GE_EST"
colnames(wgi)[colnames(wgi)=="Measure.Values.Regulatory Quality"] <- "GQ_EST"
colnames(wgi)[colnames(wgi)=="Measure.Values.Rule of Law"] <- "RL_EST"
colnames(wgi)[colnames(wgi)=="Measure.Values.Control of Corruption"] <- "CC_EST"

#Append country IDs
wgi = append_ids(wgi)

# Add variable labels
label(wgi$VA_EST) <- "Voice and accountability, estimate  [WB WGI]"
label(wgi$PV_EST) <- "Political stability absence of violence, estimate [WB WGI]"
label(wgi$GE_EST) <- "Government effectiveness, estimate [WB WGI]"
label(wgi$GQ_EST) <- "Regulatory quality, estimate [WB WGI]"
label(wgi$RL_EST) <- "Rule of law, estimate [WB WGI]"
label(wgi$CC_EST) <- "Control of corruption, estimate [WB WGI]"

# Append suffix WGI to vairables
wgi = append_suffix(wgi,"WGI")

length(unique(wgi$country))#198
length(wgi$country) #3333

#save(wgi,file=paste(preppeddata,"PREPPED_WGI_SW_041417.RDATA",sep=""))