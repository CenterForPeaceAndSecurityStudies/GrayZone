####################################
#This code creates the augmented data
#using the WDI and Penn World Tables Data
######################################

library(readstata13)
library (Hmisc)
library(foreign)
library(dplyr)

setwd("/Users/user/Google Drive/Master IPE Data/prepped data v2/")
setwd("/Users/acegi/Google Drive/SPEC/Everyone/Master IPE Data/prepped data v2/")

load("prepped_wdi.RDATA")

load("PREPPED_PW_SW_032317.RDATA")

wdi_pwt <- full_join(wdi, pw, by = c("gwno", "year")) 

# population

wdi_pwt$popraw_PW <- (wdi_pwt$pop_PW*1000000)
popest <- lm(formula = wdi_pwt$pop_WDI ~ 0 + wdi_pwt$popraw_PW)
popfit <- predict.lm(popest)

wdi_pwt$pop_full <- wdi_pwt$pop_WDI

for(n in 1:nrow(wdi_pwt)){
  if(is.na(wdi_pwt[n, 'pop_full'] == TRUE)){
    wdi_pwt[n, 'pop_full'] = wdi_pwt[n, 'popraw_PW'] * 0.9985 
  }
}

# gdp

wdi_pwt$rgdpnaraw_PW = wdi_pwt$rgdpna_PW*1000000
gdpest <- lm(formula = wdi_pwt$gdp_WDI ~ 0 + wdi_pwt$rgdpnaraw_PW)

wdi_pwt$gdp_full <- wdi_pwt$gdp_WDI

for(n in 1:nrow(wdi_pwt)){
  if(is.na(wdi_pwt[n, 'gdp_full'] == TRUE)){
    wdi_pwt[n, 'gdp_full'] = wdi_pwt[n, 'rgdpnaraw_PW'] * 0.8369
  }
}

# gdp per capita

wdi_pwt$gdppc_PW = wdi_pwt$rgdpna_PW / wdi_pwt$pop_PW
gdppcest <- lm(formula = wdi_pwt$gdppc_WDI ~ 0 + wdi_pwt$gdppc_PW)
wdi_pwt$gdppc_full <- wdi_pwt$gdppc_WDI

for(n in 1:nrow(wdi_pwt)){
  if(is.na(wdi_pwt[n, 'gdppc_full'] == TRUE)){
    wdi_pwt[n, 'gdppc_full'] = wdi_pwt[n, 'gdppc_PW'] * 0.7333
  }
}

# growth

wdi_pwt$growth_PW = NA
wdi_pwt$growth_PW = as.numeric(wdi_pwt$growth_PW)

for(n in 1:nrow(wdi_pwt)){
  year = wdi_pwt[n, 'year']
  if(identical(wdi_pwt[n, 'country.x'], wdi_pwt[n+1, 'country.x']) == TRUE){
    wdi_pwt[n+1, 'growth_PW'] = (((wdi_pwt[n+1, 'rgdpna_PW']/wdi_pwt[n, 'rgdpna_PW'])-1)*100)
  }
}

growthest <- lm(formula = wdi_pwt$growth_WDI ~ 0 + wdi_pwt$growth_PW)

wdi_pwt$growth_full = wdi_pwt$growth_WDI

for(n in 1:nrow(wdi_pwt)){
  if(is.na(wdi_pwt[n, 'growth_full'] == TRUE)){
    wdi_pwt[n, 'growth_full'] = wdi_pwt[n, 'growth_PW'] * 0.8167
  }
}

wdi_pwt = wdi_pwt[,c(1:7, 99:ncol(wdi_pwt))]
wdi_pwt = wdi_pwt[,-c(8,10,12,14)]
columnNames = colnames(wdi_pwt)
columnNames = sub(".x", "", columnNames)
colnames(wdi_pwt) = columnNames

#logged variables
wdi_pwt$lnpop_full = log(wdi_pwt$pop_full)
wdi_pwt$lngdp_full = log(wdi_pwt$gdp_full)
wdi_pwt$lngdppc_full = log(wdi_pwt$gdppc_full)

n_occur <- data.frame(table(wdi_pwt$gwno, wdi_pwt$year))
print(n_occur[n_occur$Freq > 1,])


range(wdi_pwt$year)
sum(is.na(wdi_pwt$year))
which(is.na(wdi_pwt$year))
length(unique(wdi_pwt$gwno)) #201
sum(is.na(wdi_pwt$country))
sum(is.na(wdi_pwt$gwno))

#getting rid of rows with no country name
wdi_pwt = wdi_pwt[-(10927:nrow(wdi_pwt)),]

#name "FULL"
save(wdi_pwt,file=paste(preppeddata,"prepped_FULL.RDATA",sep=""))
