###############################
# Major Episodes of Political Violence (MEPV) [PV]
# Version: 1946-2015
# Accessed: April 27, 2017
# Year Range: 1946-2015
# Prepped By: Rohit Madan
# Suffix: PV
# Last update: 04/30/2017
#
# Data: http://www.systemicpeace.org/inscrdata.html
# 
#
#
# Note: This is the standard version of the data not including data on neighbouring states. 
###############################

library(readxl)

pvStd = read_excel(path = (paste(rawdata, "RAWDATA_PV_2015_Marshall.xls", sep="")))


#Keep only these variables
varsToKeep <- c("country", "year", "intind", "intviol", "intwar", "civviol", "civwar", "ethviol", "ethwar", "inttot", "civtot", "actotal", "nborder")
pvStd <- pvStd[varsToKeep]

#Append ids
pvStd <- append_ids(pvStd, breaks = T)

backup <- pvStd

pvStd <- backup
#Check Duplicates
n_occur <- data.frame(table(pvStd$country, pvStd$year))
print(n_occur[n_occur$Freq > 1,])

# Vietnam Duplicates
pvStd = pvStd[-which(pvStd$countryname_raw == "Vietnam" & pvStd$year == 1954),]




## Append Suffix
pvStd <- append_suffix(pvStd, "PV")

#Label
library(Hmisc)
label(pvStd$intind_PV) <- "War of Independence, Magnitude [PV]" 
label(pvStd$intviol_PV) <- "International Violence, Magnitude [PV]" 
label(pvStd$intwar_PV) <- "International Warfare, Magnitude [PV]" 
label(pvStd$civviol_PV) <- "Civil Violence, Magnitude [PV]" 
label(pvStd$civwar_PV) <- "Civil War, Magnitude [PV]" 
label(pvStd$ethviol_PV) <- "Ethnic violence, Magnitude [PV]" 
label(pvStd$ethwar_PV) <- "Ethnic War, Magnitude [PV]" 
label(pvStd$inttot_PV) <- "Total interstate MEPVS, Magnitude [PV]" 
label(pvStd$civtot_PV) <- "Total civil and ethnic MEPVS, Magnitude [PV]" 
label(pvStd$actotal_PV) <- "Total MEPVS, Magnitude [PV]" 
label(pvStd$nborder_PV) <- "Number of states sharing a border [PV]" 

#save prepped data
save(pvStd,file=paste(preppeddata,"PREPPED_PV_RM_300417.RDATA",sep=""))


years <- unique(pvStd$year)
years
length(unique(pvStd$country))
range(pvStd$year)
