# /*************************
#   Bodea and Hicks Central Bank Independence Data
# 
# Source: Bodea, Cristina, and Raymond Hicks.  2015.  "Price Stability 
# and Central Bank Independence: Discipline, Credibility, and 
# Democratic Institutions."  International Organization 69: 35-61.
# 
# URL: http://www.princeton.edu/~rhicks/data/cb_rh_data.zip
# 
# Variables:
#   - Central Bank Independence score
# - Weighted Central Bank Independence score
# - Reform year (yes/no)
# *************************/
library(foreign)
library(Hmisc)

cbi = read.dta(paste(rawdata,"RAWDATA_BH_CBI.dta",sep=""))

#Keep only the variables we need
cbi = cbi[, c("year", "lvau", "lvaw", "reform", "countryname", "cowcode")]

#Rename some variables
names(cbi)[names(cbi)=="lvau"] = "cbi"
names(cbi)[names(cbi)=="lvaw"] = "cbiw"

#Append country IDs
cbi = append_ids(cbi)


#Add variable labels
label(cbi$cbi) <- "Central bank indepedence score [BH]"
label(cbi$cbiw) <- "Weighted Central Bank Independence score [BH]"
label(cbi$reform) <- "Reform year (yes/no) [BH]"

cbi = append_suffix(cbi,"BH")

length(unique(cbi$gwno)) #83
range(cbi$year) #1972 - 2010

save(cbi,file=paste(preppeddata,"prepped_BH_CBI.RDATA",sep=""))
