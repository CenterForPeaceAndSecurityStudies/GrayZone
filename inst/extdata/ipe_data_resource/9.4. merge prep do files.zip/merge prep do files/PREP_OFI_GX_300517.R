# /*********************************
# Dataset: BEA US Outward FDI Flows, by Industry
# 
# Source citation:
#   U.S. Bureau of Economic Analysis. U.S. Direct Investment Abroad, Financial Outflow Transactions Without Current-Cost Adjustment. 
# 
# Source URL: 
# http://www.bea.gov/international/di1usdbal.htm. Accessed on June 21 2016.
# 
# By: Anisha Chinwalla and Grace Xu
# Last update: 03/20/2017
# Suffix:OFI 
#   
# Variables: 
#   -ind_total_OFI    US Outward FDI: All Industries, in mil. USD [OFI]
#   -mining_OFI	      US Outward FDI: Mining, in mil. USD [OFI]
#   -util_OFI	        US Outward FDI: Utilities, in mil. USD [OFI]
#   -mf_total_OFI	    US Outward FDI: Manufacturing: Total Manufacturing, in mil. USD [OFI]
#   -mf_food_OFI	    US Outward FDI: Manufacturing: Food, in mil. USD [OFI]
#   -mf_chem_OFI	    US Outward FDI: Manufacturing: Chemicals, in mil. USD [OFI]
#   -mf_pfm_OFI	      US Outward FDI: Manufacturing: Primary and fabricated metals, in mil. USD [OFI]
#   -mf_mc_OFI	      US Outward FDI: Manufacturing: Machinery, in mil. USD [OFI]
#   -mf_cep_OFI	      US Outward FDI: Computers and electronic products, in mil. USD [OFI]
#   -mf_eeac_OFI	    US Outward FDI: Electrical equipment, appliances, components, in mil. USD [OFI]
#   -mf_te_OFI	      US Outward FDI: Manufacturing: Transportation Equipment, in mil. USD [OFI]
#   -mf_other_OFI	    US Outward FDI: Manufacturing: Other Manufacturing, in mil. USD [OFI]
#   -wt_OFI	          US Outward FDI: Wholesale Trade, in mil. USD [OFI]
#   -info_OFI	        US Outward FDI: Information, in mil. USD [OFI]
#   -dep_ins_OFI	    US Outward FDI: Depository Institutions, in mil. USD [OFI]
#   -fi_OFI	          US Outward FDI: Finance (no depository inst.) and insurance, in mil. USD [OFI]
#   -psts_OFI	        US Outward FDI: Professional, scientific, technical services, in mil. USD [OFI]
#   -hc_nb_OFI	      US Outward FDI: Holding Companies (nonbank), in mil. USD [OFI]
#   -ind_other_OFI	  US Outward FDI: Other Industries, in mil. USD [OFI]
#
#  ****************************/

library(foreign)
library(dplyr)
library(tidyr)
library(xlsx)
library(Hmisc)

setwd(rawdata)

## create heading vector of dataset
#1982-1998
headings1 <- c("country","ind_total", "Petro", "mf_total","mf_food","mf_chem","mf_pfm","mf_mc",
               "mf_eeac","mf_te","mf_other","wt","dep_ins","fi","psts","ind_other", "year") 
#1999 - 2002
headings2 <- c("country","ind_total", "mining", "util", "mf_total","mf_food","mf_chem","mf_pfm","mf_mc", 
               "mf_cep","mf_eeac","mf_te","wt","info","dep_ins","fi","psts","ind_other","year")
#2003 - 2009
headings3 <- c("country","ind_total", "mining","mf_total","mf_food","mf_chem","mf_pfm","mf_mc", "mf_cep",
               "mf_eeac","mf_te","mf_other","wt","info","dep_ins","fi","psts", "hc_nb","other","year")

## read in first sheet of each data set, standardize headings, and 
#    use for loop to read in each sheet of each spreadsheet. repeat for each spreadsheet

#################### Position ####################

## Spreadsheet: Position 1982-1989
pos8289 <- read.xlsx("BEA US Outflows Raw Data Spreadsheets/RAWDATA_OFI_2016_BEA_Position Abroad 1982-1989.xls", 1,
                     startRow = 4, endRow = 96) %>%
  mutate(year = 1982)

names(pos8289) <- headings1 
years_pos8289 <- c(1982:1989)

for(k in 2:8){
  pos8289_temp <- read.xlsx("BEA US Outflows Raw Data Spreadsheets/RAWDATA_OFI_2016_BEA_Position Abroad 1982-1989.xls",
                            k, startRow = 4, endRow = 96) %>%
    mutate(year = years_pos8289[k])
  
  names(pos8289_temp) <- headings1
  
  pos8289 <- merge(pos8289, pos8289_temp, all = TRUE)
}

remove(pos8289_temp)

## Spreadsheet: Position 1990-1999
pos9099 <- read.xlsx("BEA US Outflows Raw Data Spreadsheets/RAWDATA_OFI_2016_BEA_USDIA 1990-1999.xls",1,
                     startRow = 5, endRow = 95) %>%
  mutate(year = 1990)

names(pos9099) <- headings1

years_pos9099 <- c(1990:1999)

for(k in 2:9){
  pos9099_temp <- read.xlsx("BEA US Outflows Raw Data Spreadsheets/RAWDATA_OFI_2016_BEA_Position Abroad 1990-1999.xls",
                            k, startRow = 4, endRow = 97) %>%
    mutate(year = years_pos9099[k])
  names(pos9099_temp)[1:16] <- headings1[1:16]
  
  pos9099 <- merge(pos9099, pos9099_temp, all = TRUE)
}

pos9099_temp <- read.xlsx("BEA US Outflows Raw Data Spreadsheets/RAWDATA_OFI_2016_BEA_Position Abroad 1990-1999.xls",10,
                          startRow = 4, endRow = 97) %>%
  mutate(year = years_pos9099[10])

names(pos9099_temp) <- headings2

pos9099 <- merge(pos9099, pos9099_temp, all = TRUE)

remove(pos9099_temp)

## Spreadsheet: Position 2000-2009
pos0009 <- read.xlsx("BEA US Outflows Raw Data Spreadsheets/RAWDATA_OFI_2016_BEA_USDIA 2000-2009.xls", 1,
                     startRow = 5, endRow = 95)%>%
  mutate(year = 2000)

names(pos0009) <- headings2

years_pos0009 <- c(2000:2009)

for(k in 2:3){
  pos0009_temp <- read.xlsx("BEA US Outflows Raw Data Spreadsheets/RAWDATA_OFI_2016_BEA_Position Abroad 2000-2009.xls",
                            k ,startRow = 4, endRow = 97) %>%
    mutate(year = years_pos0009[k])
  
  names(pos0009_temp) <- headings2
  
  pos0009 <- merge(pos0009, pos0009_temp, all = TRUE)
}

for(k in 4:10){
  pos0009_temp <- read.xlsx("BEA US Outflows Raw Data Spreadsheets/RAWDATA_OFI_2016_BEA_Position Abroad 2000-2009.xls",
                            k ,startRow = 4, endRow = 96) %>%
    mutate(year = years_pos0009[k])
  
  names(pos0009_temp) <- headings3
  
  pos0009 <- merge(pos0009, pos0009_temp, all = TRUE)
}

remove(pos0009_temp)

## Spreadsheet: Position 2010-2015
pos1015 <- read.xlsx("BEA US Outflows Raw Data Spreadsheets/RAWDATA_OFI_2016_BEA_Position Abroad 2010-2015.xlsx",1,
                     startRow = 4, endRow = 96)%>%
  mutate(year = 2010)

names(pos1015) <- headings3

years_pos1015 <- c(2010:2015)

for(k in 2:5){
  pos1015_temp <- read.xlsx("BEA US Outflows Raw Data Spreadsheets/RAWDATA_OFI_2016_BEA_Position Abroad 2010-2015.xlsx",
                            k ,startRow = 4, endRow = 96) %>%
    mutate(year = years_pos1015[k])
  
  names(pos1015_temp) <- headings3
  
  pos1015 <- merge(pos1015, pos1015_temp, all = TRUE)
}

remove(pos1015_temp)

#merge position data
pos <- merge(pos8289, pos9099, all = TRUE)
pos <- merge(pos, pos0009, all = TRUE)
pos <- merge(pos, pos1015, all = TRUE)

#cleanup
remove(pos8289)
remove(pos9099)
remove(pos0009)
remove(pos1015)

## remove blank rows
#cleaning, getting only rows that have a value for country
pos = pos[!(is.na(pos$country) | pos$country==" "), ]


#################### All Variables ####################

## select variables that are in IPE

beaoutflows <- select(pos, country, year, ind_total, mining, util, mf_total, mf_food, mf_chem, mf_pfm, mf_mc,
              mf_cep, mf_eeac, mf_te, mf_other, wt, info, dep_ins, fi, psts, hc_nb, ind_other)

## label variables
#position labels
label(beaoutflows$ind_total) = "US Outward FDI: All Industries, in mil. USD [OFI]"
label(beaoutflows$mining) = "US Outward FDI: Mining, in mil. USD [OFI]"
label(beaoutflows$util) = "US Outward FDI: Utilities, in mil. USD [OFI]"
label(beaoutflows$mf_total) = "US Outward FDI: Manufacturing: Total Manufacturing, in mil. USD [OFI]"
label(beaoutflows$mf_food) = "US Outward FDI: Manufacturing: Food, in mil. USD [OFI]"
label(beaoutflows$mf_chem) = "US Outward FDI: Manufacturing: Chemicals, in mil. USD [OFI]"
label(beaoutflows$mf_pfm) = "US Outward FDI: Manufacturing: Primary and fabricated metals, in mil. USD [OFI]"
label(beaoutflows$mf_mc) =  "US Outward FDI: Manufacturing: Machinery, in mil. USD [OFI]"
label(beaoutflows$mf_cep) =  "US Outward FDI: Computers and electronic products, in mil. USD [OFI]"
label(beaoutflows$mf_eeac) = "US Outward FDI: Electrical equipment, appliances, components, in mil. USD [OFI]"
label(beaoutflows$mf_te) = "US Outward FDI: Manufacturing: Transportation Equipment, in mil. USD [OFI]"
label(beaoutflows$mf_other) =  "US Outward FDI: Manufacturing: Other Manufacturing, in mil. USD [OFI]"
label(beaoutflows$wt) = "US Outward FDI: Wholesale Trade, in mil. USD [OFI]"
label(beaoutflows$info) = "US Outward FDI: Information, in mil. USD [OFI]"
label(beaoutflows$dep_ins) = "US Outward FDI: Depository Institutions, in mil. USD [OFI]"
label(beaoutflows$fi) = "US Outward FDI: Finance (no depository inst.) and insurance, in mil. USD [OFI]"
label(beaoutflows$psts) = "US Outward FDI: Professional, scientific, technical services, in mil. USD [OFI]"
label(beaoutflows$hc_nb) = "US Outward FDI: Holding Companies (nonbank), in mil. USD [OFI]"
label(beaoutflows$ind_other) = "US Outward FDI: Other Industries, in mil. USD [OFI]"

## call appendIDs
beaoutflows = append_ids(beaoutflows, breaks = F)

## call append_suffix
beaoutflows <- append_suffix(beaoutflows, "OFI")

save(beaoutflows, file = paste(preppeddata,"prepped_OFI.RDATA", sep=""))