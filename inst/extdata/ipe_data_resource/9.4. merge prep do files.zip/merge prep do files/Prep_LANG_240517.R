# /************************* 
# Data: Reporters Without Borders: Freedom of the Press [LANG]
# Data source url: https://rsf.org/en/ranking_table?sort=asc&order=Country
# Codebook url: https://rsf.org/en/detailed-methodology

# Time:2012-2016	
# By: Sherry
# Suffix: LANG
# 
# Citation:
# Reporters Without Borders. 2017. "World Press Freedom Index". 
# https://rsf.org/en/ranking_table Accessed on May 22, 2017


# *************************/

library(foreign)
library(Hmisc)
library(plyr)
library(readxl)
library(reshape)
library(dplyr)


# Read the excel file that contains year 2012- 2014
LANG <-read_excel(paste(rawdata,"RAWDATA_LANG.xlsx", sep=""),sheet = 6, na = "NA")

# Add one column with year 2015 to run append_ids
LANG[,"Year"] <- '2015'


# Rename Column Variables
names(LANG)[names(LANG)=="language 1"] = "lang1"
names(LANG)[names(LANG)=="language2"] = "lang2"


LANG = append_ids(LANG)

# Drop the column year
LANG$year <- NULL

#length(unique(LANG$country))
sum(is.na(LANG$country))


# Merge Lang and Simple CI
load(paste(rawdata, "Country_GWNO_Year_Simple.RDATA", sep = ""))
LANG <- merge(LANG,simpleCY, by=c("gwno"), all = TRUE)
sum(is.na(LANG$country))

# Remove rows with empty country entries
LANG <- LANG[!rowSums(is.na(LANG["country"])),]
sum(is.na(LANG$country))


# --- Checking for duplicates: no duplicates
n_occur <- data.frame(table(LANG$country, LANG$year))
n_occur[n_occur$Freq > 1,]

# Check if successfully append year
# DF <- LANG[LANG[, "gwno"] == 2,]

# Label Variables
label(LANG$lang1) <- "Language 1 [LANG]"
label(LANG$lang2) <- "Language 2 [LANG]"

sum(is.na(LANG$year))
length(unique(LANG$gwno))
range(LANG$year)

# Append suffix LANG to vairables
LANG = append_suffix(LANG,"LANG")


save(LANG,file=paste(preppeddata,"PREPPED_LANG_SW_052517.RDATA",sep=""))



