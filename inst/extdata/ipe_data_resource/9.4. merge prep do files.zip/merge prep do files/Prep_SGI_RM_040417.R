###############################
# SGI Quality of Governance Indicators
# Version: 2016
# Accessed: April 04, 2017
# Year Range: 2014-2016
# Prepped By: Rohit Madan
# Suffix: SGI
# Last update: 04/04/2017
#
# Data: http://www.sgi-network.org/2016/Downloads
# Codebook: http://www.sgi-network.org/docs/2016/basics/SGI2016_Codebook.pdf
#   
# Citation: Bertelsmann Stiftung. 2016. Sustainable Governance Indicators 
# 2016. http://www.sgi-network.org/2016/Downloads. Accessed on April 04, 2017.
#
# Variables: corrupprev_SGI, Label: "Rule of Law: Corruption Prevention [SGI]"
#
#
###############################

library(readxl)

#Read raw data 2016
sgi16 = read_excel(path = (paste(rawdata, "RAWDATA_SGI_2016_Bertelsmann.xls", sep="")), sheet = "SGI 2016 Scores", skip = 0)

#For 2016 sheet
#Keep the corruption prevention variable
sgi16$country <- sgi16$`SGI
2016
Scores`

sgi16$`SGI
2016
Scores` <- NULL

varsToKeep <- c("country", " Corruption Prevention")
sgi16 <- sgi16[varsToKeep]

sgi16$year <- 2016

#Read raw data 2015
sgi15 = read_excel(path = (paste(rawdata, "RAWDATA_SGI_2016_Bertelsmann.xls", sep="")), sheet = "SGI 2015 Scores", skip = 0)

#For 2015 sheet
#Keep the corruption prevention variable
sgi15$country <- sgi15$`SGI
2015
Scores`

sgi15$`SGI
2015
Scores` <- NULL

varsToKeep <- c("country", " Corruption Prevention")
sgi15 <- sgi15[varsToKeep]

sgi15$year <- 2015

#Read raw data 2014
sgi14 = read_excel(path = (paste(rawdata, "RAWDATA_SGI_2016_Bertelsmann.xls", sep="")), sheet = "SGI 2014 Scores", skip = 0)

#For 2014 sheet
#Keep the corruption prevention variable
sgi14$country <- sgi14$`SGI
2014
Scores`

sgi14$`SGI
2014
Scores` <- NULL

varsToKeep <- c("country", " Corruption Prevention")
sgi14 <- sgi14[varsToKeep]

sgi14$year <- 2014

#Merge all three years
sgi <- rbind(sgi14, sgi15, sgi16)

#Change name of variable
names(sgi)[names(sgi)==" Corruption Prevention"] <- "corrupprev"

#Append ids
source(paste(dofiles, "append_ids.R",sep=""))
sgi <- append_ids(sgi, breaks = T)

## Append Suffix
sgi <- append_suffix(sgi, "SGI")

#Label
library(Hmisc)
label(sgi$corrupprev_SGI) <- "Rule of Law: Corruption Prevention [SGI]" 

#save prepped data
save(sgi,file=paste(preppeddata,"PREPPED_SGI_RM_060417.RDATA",sep=""))

