# /*************************
# Economic Freedom of the World from the Fraser Institute
# 
# Source: Gwartney, James, Robert A. Lawson, Joshua C. Hall, and Fred McMahon. 2016. "Economic Freedom of the World." Fraser Institute. 
# 
# URL: https://www.fraserinstitute.org/economic-freedom/dataset
# 
# Variables:
# Top marginal income tax rate
# Top marginal income and payroll tax rate
# Protection of property rights
# Impartial courts
# Business cost of crime
# Reliability of police
#
# *************************/

# --- hmisc will be needed for all packages as we use it for the append_ids function
library(Hmisc)
library(readxl)

# --- importing dataset
ef <- read_excel(paste(rawdata,"RAWDATA_EF_2014_Gwartney.xls", sep=""), 1, col_names = FALSE)


# Delete rows till Year
ef[is.na(ef)] <- "."

for(x in 1: nrow(ef)){
  if(ef[[x,1]] =="Year"){
    break
  }
}

ef <- ef[c(x:nrow(ef)), ]


# adding column headers
colnames(ef) <- ef[1,]

# getting rid of headers, as well as end has a lot of blank rows
ef = ef[c(-1),]

#Keep only the variables we need
ef = ef[, c("Year", 
            "Countries", 
            "Top marginal income tax rate", 
            "Top marginal income and payroll tax rate", 
            "Protection of property rights", 
            "Impartial courts", 
            "Business costs of crime", 
            "Reliability of police")]

#Rename some variables
names(ef)[names(ef)=="Countries"] = "countryname"
names(ef)[names(ef)=="Top marginal income tax rate"] = "top_margintax"
names(ef)[names(ef)=="Top marginal income and payroll tax rate"] = "top_margin_payrolltax"
names(ef)[names(ef)=="Protection of property rights"] = "propright"
names(ef)[names(ef)=="Impartial courts"] = "impartcourts"
names(ef)[names(ef)=="Business costs of crime"] = "bizcrimecost"
names(ef)[names(ef)=="Reliability of police"] = "policerely"

#Append country IDs
ef = append_ids(ef)
ef = append_suffix(ef,"EF")

#Change data types
ef$year = as.numeric(ef$year)
ef$top_margintax_EF = as.numeric(ef$top_margintax_EF)
ef$top_margin_payrolltax_EF = as.numeric(ef$top_margin_payrolltax_EF)
ef$propright_EF = as.numeric(ef$propright_EF)
ef$impartcourts_EF = as.numeric(ef$impartcourts_EF)
ef$bizcrimecost_EF = as.numeric(ef$bizcrimecost_EF)
ef$policerely_EF = as.numeric(ef$policerely_EF)

#Add variable labels
label(ef$top_margintax_EF) = "Top marginal income tax rate [EF]"
label(ef$top_margin_payrolltax_EF) = "Top marginal income and payroll tax rate [EF]"
label(ef$propright_EF) = "Protection of property rights [EF]"
label(ef$impartcourts_EF) = "Impartial courts [EF]"
label(ef$bizcrimecost_EF) = "Business cost of crime [EF]"
label(ef$policerely_EF) = "Reliability of police [EF]"

save(ef,file=paste(preppeddata,"PREPPED_EF_GX_270217.RDATA",sep=""))
