###############################
# Political Terror Scale [PTS]
# Version: September 2016
# Accessed: April 28, 2017
# Year Range: 1976-2015
# Prepped By: Rohit Madan
# Suffix: PTS
# Last update: 04/28/2017
#
# Data: http://www.politicalterrorscale.org/Data/Download.html
# 
#
# Variables: politterr_a_PTS, politterr_s_PTS, politterr_HRW_PTS
#
# Notes: Israel in Occupied Territories and Israel in pre-1976 borders is dropped
#        Just 'Israel' is retained
# 
###############################
library(foreign)
pts <- read.dta((paste(rawdata, "RAWDATA_PTS_2016_Gibney.dta", sep="")))

#Look into variable country_old
pts$Country <- as.character(pts$Country)
pts$Country_OLD <- as.character(pts$Country_OLD)
which(pts$Country != pts$Country_OLD)

#Keep needed variables
varsToKeep <- c("Country", "Year", "PTS_A", "PTS_H", "PTS_S")
pts <- pts[varsToKeep]

#Rename
names(pts)[names(pts)=="PTS_A"] <- "politterr_a"
names(pts)[names(pts)=="PTS_H"] <- "politterr_HRW"
names(pts)[names(pts)=="PTS_S"] <- "politterr_s"

#Append ids
pts <- append_ids(pts, breaks = T)

backup <- pts

pts <- backup

# Check Duplicates
n_occur <- data.frame(table(pts$country, pts$year))
print(n_occur[n_occur$Freq > 1,])

# --- Drop the duplicates
# Yemen Duplicates
pts = pts[-which(pts$countryname_raw == "Yemen" & pts$year <= 1989),]
pts = pts[-which(pts$countryname_raw == "Yemen Arab Republic" & pts$year > 1989),]

# Serbia and Yugoslavia Duplicates
pts = pts[-which(pts$countryname_raw == "Serbia and Montenegro" & pts$year >= 2007),]
pts = pts[-which(pts$countryname_raw == "Yugoslavia" & pts$year >= 2007),]
pts = pts[-which(pts$countryname_raw == "Serbia" & pts$year < 2007),]

pts = pts[-which(pts$countryname_raw == "Serbia and Montenegro" & pts$year <= 2003),]
pts = pts[-which(pts$countryname_raw == "Yugoslavia" & pts$year > 2003),]

# Germany Duplicates
pts = pts[-which(pts$countryname_raw == "Germany" & pts$year < 1990),]
pts = pts[-which(pts$countryname_raw == "German Federal Republic" & pts$year >= 1990),]

# Russia Duplicates
pts = pts[-which(pts$countryname_raw == "Russian Federation" & pts$year <= 1991),]
pts = pts[-which(pts$countryname_raw == "Soviet Union" & pts$year > 1991),]

# Czech Republic Duplicates
pts = pts[-which(pts$countryname_raw == "Czech Republic" & pts$year <= 1991),]
pts = pts[-which(pts$countryname_raw == "Czechoslovakia" & pts$year > 1991),]


## Append Suffix
pts <- append_suffix(pts, "PTS")

#Label
library(Hmisc)
label(pts$politterr_a_PTS) <- "Political Terror Scale based on Amnesty International [PTS]" 
label(pts$politterr_HRW_PTS) <- "Political Terror Scale based on HRW [PTS]" 
label(pts$politterr_s_PTS) <- "Political Terror Scale based on the US State Department [PTS]" 

#save prepped data
save(pts,file=paste(preppeddata,"PREPPED_PTS_RM_280417.RDATA",sep=""))


