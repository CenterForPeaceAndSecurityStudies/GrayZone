###############################
# Major Episodes of Political Violence (MEPV) Expanded [PVE]
# Version: 1946-2012
# Accessed: April 27, 2017
# Year Range: 1946-2015
# Prepped By: Rohit Madan
# Suffix: PVE
# Last update: 04/30/2017
#
# Data: http://www.systemicpeace.org/inscrdata.html
# 
#
# Note: This is the expanded version of the data including data on neighbouring states. 
###############################

library(readxl)
pvExt = read_excel(path = (paste(rawdata, "RAWDATA_PV_2012_Expanded_Marshall.xls", sep="")))


#Keep only these variables
varsToKeep <- c("COUNTRY", "YEAR", "TOTINT", "TOTCIV", "TOTALAC", "nINT", "nCIV", "nAC", "REGION", "nREGION", "REGINT", "REGCIV", "REGAC", "nRINT", "nRCIV", "nRAC")
pvExt <- pvExt[varsToKeep]

#Rename
names(pvExt) <- tolower(names(pvExt))


#Append ids
pvExt <- append_ids(pvExt, breaks = T)

backup <- pvExt

pvExt <- backup
#Check Duplicates
n_occur <- data.frame(table(pvExt$country, pvExt$year))
print(n_occur[n_occur$Freq > 1,])


# Vietnam Duplicates
pvExt = pvExt[-which(pvExt$countryname_raw == "Vietnam" & pvExt$year == 1954),]

# Yemen Duplicates
pvExt = pvExt[-which(pvExt$countryname_raw == "Yemen, North" & pvExt$year == 1990),]


## Append Suffix
pvExt <- append_suffix(pvExt, "PVE")

#Label
library(Hmisc)
label(pvExt$totint_PVE) <- "Sum of interstate MEPV magnitude scores for neighboring states [PVE]" 
label(pvExt$totciv_PVE) <- "Sum of civil and ethnic MEPVs in neighboring states [PVE]" 
label(pvExt$totalac_PVE) <- "Sum of all MEPVs in neighboring states [PVE]" 
label(pvExt$nint_PVE) <- "Number of bordering states with international MEPVs [PVE]" 
label(pvExt$nciv_PVE) <- "Number of bordering states with civil or ethnic MEPVs [PVE]" 
label(pvExt$nac_PVE) <- "Number of bordering states with any MEPVs [PVE]" 
label(pvExt$region_PVE) <- "Region [PVE]" 
label(pvExt$nregion_PVE) <- "Number of states in region [PVE]" 
label(pvExt$regint_PVE) <- "Sum of interstate MEPV magnitude scores in region [PVE]" 
label(pvExt$regciv_PVE) <- " Sum of civil and ethnic MEPVs in region [PVE]" 
label(pvExt$regac_PVE) <- "Sum of all MEPVs in region [PVE]" 
label(pvExt$nrint_PVE) <- "Number of states in region with international MEPVs [PVE]" 
label(pvExt$nrciv_PVE) <- "Number of states in region with civil or ethnic MEPVs [PVE]" 
label(pvExt$nrac_PVE) <- "Number of states in region with any MEPVs [PVE]" 

length(unique(pvExt$gwno))  #172
range(pvExt$year) #1946 - 2012

#save prepped data
save(pvExt,file=paste(preppeddata,"PREPPED_PVE_RM_300417.RDATA",sep=""))

