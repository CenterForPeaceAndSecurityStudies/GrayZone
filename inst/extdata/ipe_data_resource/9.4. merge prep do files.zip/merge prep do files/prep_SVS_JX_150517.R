# /************************* 
# Source: The Political Terror Scale
# Accessed: May 15, 2017
# URL: http://www.politicalterrorscale.org/Data/Download.html 
# Query specifications: all countries, all years, variables: Societal violence scale (1-5 with 5 being highest)
# 
# Time: 2013-2014
# By: Jessica Xu 
# Suffix: SVS
# Variables: Societal violence scale (1-5 with 5 being highest)
# *************************/

library(Hmisc)
library(readxl)
library(dplyr)
library(tidyr)
library(stringr)

#import
SVS <- read_excel(paste(rawdata, "RAWDATA_SVS.xlsx", sep = ""))

SVS = SVS[,1:4] 
SVS = SVS[rowSums(is.na(SVS)) != ncol(SVS),]

#adding a new column that specifies year
SVS = gather(SVS, "year", "sociaviol", 3:ncol(SVS))
#Keep only the variables we need
SVS = SVS[, c("Country",
            "year",
            "sociaviol")]

#label
label(SVS$sociaviol) <- "societal violence scale (1-5 with 5 being highest) [SVS]"

#appending gwnos
SVS = append_ids(SVS)

#append suffix
SVS = append_suffix(SVS, "SVS")

save(SVS,file=paste(preppeddata,"PREPPED_SVS_JX_150517.RDATA",sep=""))

