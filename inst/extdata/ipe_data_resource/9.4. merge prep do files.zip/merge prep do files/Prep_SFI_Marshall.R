# /************************* 
# Data: State Fragility Index
# Dataset: State Fragility Index and Matrix, Time-Series Data, 1995-2015
# Data source url: http://www.systemicpeace.org/inscrdata.html
# Codebook url: http://www.systemicpeace.org/vlibrary/GlobalReport2014.pdf

# Time:1996-2015	
# By: Sherry
# Suffix: SFI
# 
# Citation:
# Marshall, Monty G., and Benjamin R. Cole. 2011. 
# “State Fragility Index and Matrix 2011.” Center for Systemic Peace. 
# http://www.systemicpeace.org/inscr/inscr.htm.
# 
# Monty G. Marshall and Benjamin R. Cole. 2011. 
# Global Report 2011: Conflict, Governance, and State Fragility. Vienna, VA: Center for Systemic Peace.

# *************************/

library(foreign)
library(Hmisc)
library(plyr)
library(readxl)

#import
sfi <-read_excel(paste(rawdata,"RAWDATA_SFI_2016_Marshall.xls",sep=""))

# Number of countries and observations before cleaning
length(unique(sfi$country)) #169
length(sfi$country) #3459

# Remove col Scode and Region
sfi$scode <- NULL
sfi$region <- NULL

#Append country IDs
sfi = append_ids(sfi)

# Add variable labels
label(sfi$sfi) <- "State fragility index [SFI]"
label(sfi$effect) <- "Effectiveness score [SFI]"
label(sfi$legit) <- "Legitimacy score [SFI]"
label(sfi$seceff) <- "Security effectiveness score [SFI]"
label(sfi$secleg) <- "Security legitimacy score [SFI]"
label(sfi$poleff) <- "Political effectiveness score [SFI]"
label(sfi$polleg) <- "Political legitimacy score [SFI]"
label(sfi$ecoeff) <- "Economic effectiveness score [SFI]]"
label(sfi$ecoleg) <- "Economic legitimacy score [SFI]"
label(sfi$soceff) <- "Social effectiveness score [SFI]"
label(sfi$socleg) <- "Social legitimacy score [SFI]"

# Append suffix SFI to vairables
sfi = append_suffix(sfi,"SFI")

save(sfi,file=paste(preppeddata,"PREPPED_SFI_SW_041417.RDATA",sep=""))
