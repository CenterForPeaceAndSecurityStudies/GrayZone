# /**************************
# Data: Composite Index of National Capability (CINC) index 
# Dataset: COW materials capabilities (CINC) data
# Data source url: http://www.correlatesofwar.org/data-sets/national-material-capabilities
# Codebook url: http://www.correlatesofwar.org/data-sets/national-material-capabilities/nmc-codebook-v5-1
# Time: 1816-2012
# Updated: 2017.02.01
# By: Sherry
# Suffix: MC
# 
# Citation:
#   Singer, J. David, Stuart Bremer, and John Stuckey. (1972). "Capability Distribution, Uncertainty, 
#   and Major Power War, 1820-1965." in Bruce Russett (ed) Peace, War, and Numbers, Beverly Hills: Sage, 19-48.
# 
#   Singer, J. David. 1987. "Reconstructing the Correlates of War Dataset on Material Capabilities of States, 
#   1816-1985" International Interactions, 14: 115-32.

# #****************************/
library(foreign)
library(Hmisc)

mc = read.dta(paste(rawdata,"RAWDATA_MC_2017_Greig.dta",sep=""))

#Keep variables we are interestd
mc = mc[, c("statenme", "ccode", "year", "irst", "tpop", "upop", "cinc", "milex", "milper", "pec")]



#Rename some variables
names(mc)[names(mc)=="statenme"] = "country"

length(unique(mc$country)) # 217

length(mc$country) #15171



#Append country IDs
mc = append_ids(mc)

# Drop a couple of duplicates from Germany and Yemen

# Germany
# Germany 1945- 1949
# Drop duplicates when ccode_raw = 260 (German Federal Republic), 265 (German Democratic Republic) 
# and year = 1990
mc<-mc[!(mc$ccode_raw=="260" & mc$year==1990),]
mc<-mc[!(mc$ccode_raw=="265" & mc$year==1990),]

# Yemen
# Yemen Arab Republic YAR 1926 -1990 
# Yemen 1990 - 2012 ---------Changed to Arab Republic of Yemen
# Yemen People's Republic 1967 - 1990 
mc<-mc[!(mc$countryname_raw=="Yemen" & mc$year==1990),]

# Check duplicates
n_occur <- data.frame(table(mc$country, mc$year))
n_occur[n_occur$Freq > 1,]

#Add variable labels
label(mc$cinc) <- "CINC Score [MC]"
label(mc$milex) <- "Military Expenditures [MC]"
label(mc$milper) <- "Military Personnel  [MC]"
label(mc$irst) <- "Iron and steel production [MC]"
label(mc$pec) <- "Primary energy consumption [MC]"
label(mc$tpop) <- "Total Population [MC]"
label(mc$upop) <- "Urban population [MC]"



# Append suffix MC to vairables 
mc = append_suffix(mc,"MC")

length(unique(mc$gwno)) # 217
range(mc$year) #1816-2012

save(mc,file=paste(preppeddata,"PREPPED_MC_SW_031017.RDATA",sep=""))


