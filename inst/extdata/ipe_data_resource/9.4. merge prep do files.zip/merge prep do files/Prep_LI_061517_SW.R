# /************************* 
# Append Year to Tax Incentive Data


# *************************/

library(foreign)
library(Hmisc)
library(readstata13)


# Read the dta file from prepped data folder
LI <-read.dta13(paste(rawdata,"li_replication.dta", sep=""))



#length(unique(LI$country))
sum(is.na(LI$country))

# Merge LI and Simple CI
load(paste(rawdata, "Country_GWNO_Year_Simple.RDATA", sep = ""))
LI <- merge(LI,simpleCY, by=c("gwno"), all = TRUE)

# Remove rows with empty country entries
LI <- LI[!rowSums(is.na(LI["country"])),]

# Only keep years up to 2006 -- the year the dataset was updated
LI <- LI[LI[, "year"] < 2007, ]

# Drop ccode raw column
LI$ccode_raw <- NULL

# Add variable labels
label(LI$taxincentsum_LI) <- "Sum of six types of tax incentives [LI]"

length(unique(LI$gwno)) #53
range(LI$year) #1816-2006

save(LI,file=paste(preppeddata,"PREPPED_LI_SW_061517.RDATA",sep=""))



