# /************************* 
# Data: World Bank Education Statistics [ES]
# Data source url: http://databank.worldbank.org/data/reports.aspx?source=education-statistics-~-all-indicators

# Time:1970-2015	
# By: Sherry
# Suffix: ES
# 
# Citation:
# World Bank. 2015. Education Statistics - All Indicators. 
# http://databank.worldbank.org/data/reports.aspx?source=education-statistics-~-all-indicators
# Accessed on May 23, 2017s



# *************************/

library(foreign)
library(Hmisc)
library(reshape)

ES <-read.csv(paste(rawdata,"RAWDATA_ES_WB.csv",sep=""),header=TRUE, stringsAsFactors=FALSE)

# Keep the years 1970 - 2015
# Get rid of the notes after line 243
ES <- ES[c(1:242),c(1:2, 5:50)]

# Format the column names to just the year number 

# Create a vector to hold all the years
years <- NULL
for(i in names(ES[, c(3:48)])){
   year = substr(i, 2, 5)
   years <- c(years, year)
   names(ES)[names(ES)==i] = year
   
}

# Reshape the Dataframe so that it is country-year paired
ES <- reshape(ES, direction="long", varying=years, v.names="ptratio_seced",
                 idvar=c("Country", "Country.Code"), timevar="Year", times=1970:2015,sep = "")



#Get rid of additional attributes
row.names(ES) <- NULL


# Order the dataframe by Country name alphabetically
ES <- ES[order(ES$Country),]
ES$Country.Code <- NULL

ES = append_ids(ES)

# Add variable labels
label(ES$ptratio_seced) <- "Pupil-teacher ratio in secondary education (headcount basis) [ES]"

# Append suffix ES to vairables
ES = append_suffix(ES,"ES")

length(unique(ES$gwno))  #198
range(ES$year) #1970-2015

save(ES,file=paste(preppeddata,"PREPPED_ES_WB_SW_052417.RDATA",sep=""))




