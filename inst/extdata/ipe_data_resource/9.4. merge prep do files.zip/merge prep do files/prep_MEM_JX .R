# /************************* 
# Source: EU,IMF,NATO,WTO,OECD  
# Accessed: May 25, 2017
# URL(EU):http://europa.eu/about-eu/countries/
# URL(IMF):http://www.imf.org/external/np/sec/memdir/memdate.htm
# URL(NATO):http://www.nato.int/cps/en/natolive/topics_52044.htm
# URL(OECD):http://www.oecd.org/about/membersandpartners/list-oecd-member-countries.htm
# URL(WTO):http://www.wto.org/english/thewto_e/whatis_e/tif_e/org6_e.htm
# Query specifications: all countries, all years, variables: WTOwhen_WTO, WTOmem_WTO, IMFwhem_IMF, IMFmem_IMF, NATOwhen_NATO, NATOmem_NATO, euwhen_EU, eumem_EU, oecd_joinyear_OE,oecd_OE
# Time: 1945-2016
# By: Jessica Xu
# Suffix: CE
# Variables: WTOwhen_WTO: year of accession [WTO], WTOmem_WTO: binary, 1 if member, 0 if not [WTO], IMFwhem_IMF:year of accession [IMF],  IMFmem_IMF:binary, 1 if member, 0 if not [IMF],  NATOwhen_NATO:year of accession [NATO], NATOmem_NATO:binary, 1 if member, 0 if not [NATO],  euwhen_EU:year of accession [EU],  eumem_EU:binary, 1 if member, 0 if not [EU],  oecd_joinyear_OE:year of accession [OECD], oecd_OE:binary, 1 if member, 0 if not [OECD]
# *************************/
library(readxl)
library(tidyr)
library(dplyr)
library(splitstackshape)
library(Hmisc)
#import
MEM <- read_excel(paste(rawdata, "RAWDATA_MEM_2017.xlsx", sep=""))



n_occur <- data.frame(table(MEM$country))
print(n_occur[n_occur$Freq > 1,])

#renaming variables
names(MEM)[names(MEM)=="Eu"]="eumem_EU"
names(MEM)[names(MEM)=="Eu when"] = "euwhen_EU"
names(MEM)[names(MEM)=="NATO"] = "NATOmem_NATO"
names(MEM)[names(MEM)=="NATO When"] = "NATOwhen_NATO"
names(MEM)[names(MEM)=="WTO"] = "WTOmem_WTO"
names(MEM)[names(MEM)=="WTO when"] = "WTOwhen_WTO"
names(MEM)[names(MEM)=="IMF"] = "IMFmem_IMF"
names(MEM)[names(MEM)=="IMF When"] = "IMFwhen_IMF"
names(MEM)[names(MEM)=="OECD"] = "oecd_joinyear_OE"
names(MEM)[names(MEM)=="OECD When"] = "oecd_OE"

#label
label(MEM$eumem_EU) <- "binary, 1 if member, 0 if not [EU]"
label(MEM$euwhen_EU) <- "year of accession [EU]"
label(MEM$WTOwhen_WTO) <- " year of accession [WTO]"
label(MEM$WTOmem_WTO) <- "binary, 1 if member, 0 if not [WTO]"
label(MEM$IMFwhen_IMF) <- " year of accession [IMF]"
label(MEM$IMFmem_IMF) <- "binary, 1 if member, 0 if not [IMF]"
label(MEM$NATOwhen_NATO) <- " year of accession [NATO]"
label(MEM$NATOmem_NATO) <- "binary, 1 if member, 0 if not [NATO]"
label(MEM$oecd_joinyear_OE) <- "year of accession [OECD]"
label(MEM$oecd_OE) <- "binary, 1 if member, 0 if not [OECD]"


#appending gwnos
MEM = append_ids(MEM)
sum(is.na(MEM$country))

# Merge Lang and Simple CI
load(paste(rawdata, "Country_GWNO_Year_Simple.RDATA", sep = ""))
MEM <- merge(MEM,simpleCY, by=c("gwno"), all = TRUE)

# Remove rows with empty country entries
MEM <- MEM[!rowSums(is.na(MEM["country"])),]
sum(is.na(MEM$country))

#append suffix
MEM = append_suffix(MEM, "MEM")


length(unique(MEM$gwno))  #197
range(MEM$year)  #1816 - 2017

save(MEM,file=paste(preppeddata,"PREPPED_MEM_JX_250517.RDATA",sep=""))
