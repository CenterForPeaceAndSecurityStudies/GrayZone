###############################
# Rule of Law Index [WJP]
# Version: 2016
# Accessed: April 08, 2017
# Year Range: 2013-2016
# Prepped By: Rohit Madan
# Suffix: WJP
# Last update: 04/08/2017
#
# Data: https://worldjusticeproject.org/our-work/wjp-rule-law-index/wjp-rule-law-index-2016/current-historical-data
# Codebook: https://worldjusticeproject.org/our-work/publications/rule-law-index-reports/wjp-rule-law-index%C2%AE-2016-report
#   
# Citation: The World Justice Project. 2016. Rule of Law Index. 
# http://worldjusticeproject.org/rule-of-law-index. Accessed on: April 8, 2017.
#
# Variables: exec_crpt, judic_crpt, milt_crpt, legis_crpt, crime_ctrl, civil_cf, gov_reg, due_admin, 
# expr_comp, ppl_cj, cj_disc, cj_crpt, cj_delay, cj_enfor, adr_acces
#
# Notes: The 2012-2013 dataset was categorized as the dataset for 2013.
#
###############################

library(readxl)

#Read raw data for 2012-2013 sheet
rol13 = read_excel(path = (paste(rawdata, "RAWDATA_WJP_2016_World.XLSX", sep="")), sheet = "WJP ROL Index 2012-2013 Scores")

#Rename variables we need

names(rol13)[names(rol13) == "2.1 Government officials in the executive branch do not use public office for private gain"] <- "exec_crpt"
names(rol13)[names(rol13) == "2.2 Government officials in the judicial branch do not use public office for private gain"] <- "judic_crpt"
names(rol13)[names(rol13) == "2.3 Government officials in the police and the military do not use public office for private gain"] <- "milt_crpt"
names(rol13)[names(rol13) == "2.4 Government officials in the legislative branch do not use public office for private gain"] <- "legis_crpt"
names(rol13)[names(rol13) == "3.1 Crime is effectively controlled"] <- "crime_ctrl"
names(rol13)[names(rol13) == "3.2 Civil conflict is effectively limited"] <- "civil_cf"
names(rol13)[names(rol13) == "6.2 Government regulations are applied and enforced without improper influence"] <- "gov_reg"
names(rol13)[names(rol13) == "6.4 Due process is respected in administrative proceedings"] <- "due_admin"
names(rol13)[names(rol13) == "6.5 The Government does not expropriate without adequate compensation"] <- "expr_comp"
names(rol13)[names(rol13) == "7.1 People can access and afford civil justice"] <- "ppl_cj"
names(rol13)[names(rol13) == "7.2 Civil justice is free of discrimination"] <- "cj_disc"
names(rol13)[names(rol13) == "7.3 Civil justice is free of corruption"] <- "cj_crpt"
names(rol13)[names(rol13) == "7.5 Civil justice is not subject to unreasonable delays"] <- "cj_delay"
names(rol13)[names(rol13) == "7.6 Civil justice is effectively enforced"] <- "cj_enfor"
names(rol13)[names(rol13) == "7.7 ADRs are accessible, impartial, and effective"] <- "adr_acces"

#Keep needed variables
varNames <- c("Country", "exec_crpt", "judic_crpt", "milt_crpt", "legis_crpt", "crime_ctrl", "civil_cf", "gov_reg", "due_admin", "expr_comp", "ppl_cj", "cj_disc", "cj_crpt", "cj_delay", "cj_enfor", "adr_acces")
rol13 <- rol13[varNames]

#Give year 2013
rol13$year <- 2013

#Read raw data for 2014 sheet
rol14 = read_excel(path = (paste(rawdata, "RAWDATA_WJP_2016_World.XLSX", sep="")), sheet = "WJP ROL Index 2014 Scores")

#The variables we need here
varNums <- c("2.1", "2.2", "2.3", "2.4", "5.1", "5.2", "6.2", "6.4", "6.5", "7.1", "7.2", "7.3", "7.5", "7.6", "7.7")

contains <- integer(length = 0)
for (i in varNums){
  contains <- c(contains, sum(grep(i, rol14$Country)))
}

rol14 <- rol14[contains, ]

#reshape data
library(tidyr)

gathered <- gather(rol14, "CountryName", "indicator", 2:100)
rol14 <- spread(gathered, 'Country', 'indicator')

#The variables we need
names(rol14)[names(rol14) == "2.1 Government officials in the executive branch do not use public office for private gain"] <- "exec_crpt"
names(rol14)[names(rol14) == "2.2 Government officials in the judicial branch do not use public office for private gain"] <- "judic_crpt"
names(rol14)[names(rol14) == "2.3 Government officials in the police and the military do not use public office for private gain"] <- "milt_crpt"
names(rol14)[names(rol14) == "2.4 Government officials in the legislative branch do not use public office for private gain"] <- "legis_crpt"
names(rol14)[names(rol14) == "5.1 Crime is effectively controlled"] <- "crime_ctrl"
names(rol14)[names(rol14) == "5.2 Civil conflict is effectively limited"] <- "civil_cf"
names(rol14)[names(rol14) == "6.2 Government regulations are applied and enforced without improper influence"] <- "gov_reg"
names(rol14)[names(rol14) == "6.4 Due process is respected in administrative proceedings"] <- "due_admin"
names(rol14)[names(rol14) == "6.5 The Government does not expropriate without adequate compensation"] <- "expr_comp"
names(rol14)[names(rol14) == "7.1 People can access and afford civil justice"] <- "ppl_cj"
names(rol14)[names(rol14) == "7.2 Civil justice is free of discrimination"] <- "cj_disc"
names(rol14)[names(rol14) == "7.3 Civil justice is free of corruption"] <- "cj_crpt"
names(rol14)[names(rol14) == "7.5 Civil justice is not subject to unreasonable delays"] <- "cj_delay"
names(rol14)[names(rol14) == "7.6. Civil justice is effectively enforced"] <- "cj_enfor"
names(rol14)[names(rol14) == "7.7 ADR is accessible, impartial, and effective"] <- "adr_acces"
names(rol14)[names(rol14) == "CountryName"] <- "Country"

#Give year 2014
rol14$year <- 2014

#Read in spreadsheet for 2015
rol15 = read_excel(path = (paste(rawdata, "RAWDATA_WJP_2016_World.XLSX", sep="")), sheet = "WJP ROL Index 2015 Scores")

#The variables we need here - same as 2014
varNums <- c("2.1", "2.2", "2.3", "2.4", "5.1", "5.2", "6.2", "6.4", "6.5", "7.1", "7.2", "7.3", "7.5", "7.6", "7.7")


contains <- integer(length = 0)
for (i in varNums){
  contains <- c(contains, sum(grep(i, rol15$Country)))
}

rol15 <- rol15[contains, ]

gathered <- gather(rol15, "CountryName", "indicator", 2:103)
rol15 <- spread(gathered, 'Country', 'indicator')


names(rol15)[names(rol15) == "2.1 Government officials in the executive branch do not use public office for private gain"] <- "exec_crpt"
names(rol15)[names(rol15) == "2.2 Government officials in the judicial branch do not use public office for private gain"] <- "judic_crpt"
names(rol15)[names(rol15) == "2.3 Government officials in the police and the military do not use public office for private gain"] <- "milt_crpt"
names(rol15)[names(rol15) == "2.4 Government officials in the legislative branch do not use public office for private gain"] <- "legis_crpt"
names(rol15)[names(rol15) == "5.1 Crime is effectively controlled"] <- "crime_ctrl"
names(rol15)[names(rol15) == "5.2 Civil conflict is effectively limited"] <- "civil_cf"
names(rol15)[names(rol15) == "6.2 Government regulations are applied and enforced without improper influence"] <- "gov_reg"
names(rol15)[names(rol15) == "6.4 Due process is respected in administrative proceedings"] <- "due_admin"
names(rol15)[names(rol15) == "6.5 The government does not expropriate without lawful process and adequate compensation"] <- "expr_comp"
names(rol15)[names(rol15) == "7.1 People can access and afford civil justice"] <- "ppl_cj"
names(rol15)[names(rol15) == "7.2 Civil justice is free of discrimination"] <- "cj_disc"
names(rol15)[names(rol15) == "7.3 Civil justice is free of corruption"] <- "cj_crpt"
names(rol15)[names(rol15) == "7.5 Civil justice is not subject to unreasonable delay"] <- "cj_delay"
names(rol15)[names(rol15) == "7.6. Civil justice is effectively enforced"] <- "cj_enfor"
names(rol15)[names(rol15) == "7.7 Alternative dispute resolution mechanisms are accessible, impartial, and effective"] <- "adr_acces"
names(rol15)[names(rol15) == "CountryName"] <- "Country"

#Give year 2015
rol15$year <- 2015

#Read in spreadsheet for 2016
rol16 = read_excel(path = (paste(rawdata, "RAWDATA_WJP_2016_World.XLSX", sep="")), sheet = "WJP ROL Index 2016 Scores")

varNums <- c("2.1", "2.2", "2.3", "2.4", "5.1", "5.2", "6.2", "6.4", "6.5", "7.1", "7.2", "7.3", "7.5", "7.6", "7.7")

contains <- integer(length = 0)
for (i in varNums){
  contains <- c(contains, sum(grep(i, rol16$Country)))
}

rol16 <- rol16[contains, ]

gathered <- gather(rol16, "CountryName", "indicator", 2:114)
rol16 <- spread(gathered, 'Country', 'indicator')


names(rol16)[names(rol16) == "2.1 Government officials in the executive branch do not use public office for private gain"] <- "exec_crpt"
names(rol16)[names(rol16) == "2.2 Government officials in the judicial branch do not use public office for private gain"] <- "judic_crpt"
names(rol16)[names(rol16) == "2.3 Government officials in the police and the military do not use public office for private gain"] <- "milt_crpt"
names(rol16)[names(rol16) == "2.4 Government officials in the legislative branch do not use public office for private gain"] <- "legis_crpt"
names(rol16)[names(rol16) == "5.1 Crime is effectively controlled"] <- "crime_ctrl"
names(rol16)[names(rol16) == "5.2 Civil conflict is effectively limited"] <- "civil_cf"
names(rol16)[names(rol16) == "6.2 Government regulations are applied and enforced without improper influence"] <- "gov_reg"
names(rol16)[names(rol16) == "6.4 Due process is respected in administrative proceedings"] <- "due_admin"
names(rol16)[names(rol16) == "6.5 The government does not expropriate without lawful process and adequate compensation"] <- "expr_comp"
names(rol16)[names(rol16) == "7.1 People can access and afford civil justice"] <- "ppl_cj"
names(rol16)[names(rol16) == "7.2 Civil justice is free of discrimination"] <- "cj_disc"
names(rol16)[names(rol16) == "7.3 Civil justice is free of corruption"] <- "cj_crpt"
names(rol16)[names(rol16) == "7.5 Civil justice is not subject to unreasonable delay"] <- "cj_delay"
names(rol16)[names(rol16) == "7.6. Civil justice is effectively enforced"] <- "cj_enfor"
names(rol16)[names(rol16) == "7.7 Alternative dispute resolution mechanisms are accessible, impartial, and effective"] <- "adr_acces"
names(rol16)[names(rol16) == "CountryName"] <- "Country"

#Give year 2016
rol16$year <- 2016


#Merge all four years
rol <- rbind(rol13, rol14, rol15, rol16)

#Append ids
source(paste(dofiles, "append_ids.R",sep=""))
rol <- append_ids(rol, breaks = T)

## Append Suffix
rol <- append_suffix(rol, "WJP")

#Label
library(Hmisc)

label(rol$civil_cf_WJP) <- "Civil conflict is effectively limited [WJP]" 
label(rol$cj_crpt_WJP) <- "Civil justice is free of corruption [WJP]" 
label(rol$cj_delay_WJP) <- "Civil justice is not subject to unreasonable delays [WJP]" 
label(rol$adr_acces_WJP) <- "ADRs are accessible, impartial, and effective [WJP]" 
label(rol$cj_disc_WJP) <- "Civil justice is free of discrimination [WJP]" 
label(rol$cj_enfor_WJP) <- "Civil justice is effectively enforced [WJP]" 
label(rol$crime_ctrl_WJP) <- "Crime is effectively controlled [WJP]" 
label(rol$due_admin_WJP) <- "Due process is respected in administrative proceedings [WJP]" 
label(rol$exec_crpt_WJP) <- "Executive branch officials do not use public office for private gain [WJP]" 
label(rol$expr_comp_WJP) <- "The Government does not expropriate without adequate compensation [WJP]" 
label(rol$gov_reg_WJP) <- "Government regulations are applied and enforced without improper influence [WJP]" 
label(rol$judic_crpt_WJP) <- "Judicial branch officials do not use public office for private gain [WJP]" 
label(rol$legis_crpt_WJP) <- "Legislative branch officials do not use public office for private gain [WJP]" 
label(rol$milt_crpt_WJP) <- "Police and Military officials do not use public office for private gain [WJP]" 
label(rol$ppl_cj_WJP) <- "People have access to affordable civil justice [WJP]" 

#save prepped data
save(rol,file=paste(preppeddata,"PREPPED_WJP_RM_220417.RDATA",sep=""))


